<%@ WebHandler Language="C#" Class="MReport.ReportGateway" %>
