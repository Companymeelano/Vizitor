using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Script.Serialization;

namespace MReport
{
    /// <summary>
    /// دروازهٔ گزارش **M●D Report** — تنها نقطهٔ اتصال اپ اندرویدی به SQL Server.
    ///
    /// چرا به شکل `IHttpHandler` و نه Web API:
    ///   این سرویس هیچ وابستگی NuGet ندارد و هیچ مرحلهٔ Build نمی‌خواهد —
    ///   ASP.NET همین فایل را از `App_Code` در زمان اجرا کامپایل می‌کند.
    ///   نصب یعنی «کپی پوشه + ساخت سایت IIS»، که `install-MReportService.ps1`
    ///   یک‌جا انجامش می‌دهد.
    ///
    /// مسیر:  /Report.ashx
    ///   GET   → سلامت سرویس + نسخهٔ SQL Server
    ///   POST  → اجرای یک کوئری فقط-خواندنی و برگرداندن JSON
    ///   OPTIONS → پاسخ CORS
    ///
    /// امنیت:
    ///   ۱) فقط SELECT/WITH — هر کلیدواژهٔ نوشتاری رد می‌شود (همان فهرست سمت اپ)
    ///   ۲) چند دستور در یک درخواست ممنوع (`;`)
    ///   ۳) پارامترها همیشه SqlParameter؛ جای‌نمای `?` به `@pN` تبدیل می‌شود
    ///   ۴) نام دیتابیس فقط `[A-Za-z0-9_]` — جلوگیری از تزریق به رشتهٔ اتصال
    ///   ۵) سقف سخت ۵۰۰۰ سطر و ۱۲۰ ثانیه
    ///   ۶) کلید مشترک اختیاری با هدر `X-MReport-Key`
    /// </summary>
    public class ReportGateway : IHttpHandler
    {
        private const int HARD_MAX_ROWS = 5000;
        private const int HARD_TIMEOUT_SEC = 120;
        private const int DEFAULT_MAX_ROWS = 1000;
        private const int DEFAULT_TIMEOUT_SEC = 45;

        public bool IsReusable { get { return true; } }

        private static readonly string[] Forbidden =
        {
            "INSERT", "UPDATE", "DELETE", "DROP", "ALTER", "TRUNCATE", "MERGE",
            "EXEC", "EXECUTE", "CREATE", "GRANT", "REVOKE", "DENY",
            "BACKUP", "RESTORE", "SHUTDOWN", "KILL",
            "OPENROWSET", "OPENDATASOURCE",
        };

        public void ProcessRequest(HttpContext ctx)
        {
            var sw = Stopwatch.StartNew();
            try
            {
                ctx.Response.ContentType = "application/json; charset=utf-8";
                ctx.Response.Cache.SetNoStore();

                var method = (ctx.Request.HttpMethod ?? "GET").ToUpperInvariant();
                if (method == "OPTIONS")
                {
                    ctx.Response.StatusCode = 204;
                    return;
                }

                if (!KeyOk(ctx))
                {
                    ctx.Response.StatusCode = 401;
                    Write(ctx, Fail("کلید دسترسی نامعتبر است (هدر X-MReport-Key)"));
                    return;
                }

                if (method == "GET") { Ping(ctx); return; }
                if (method != "POST")
                {
                    ctx.Response.StatusCode = 405;
                    Write(ctx, Fail("فقط GET و POST پشتیبانی می‌شود"));
                    return;
                }

                Query(ctx);
            }
            catch (Exception ex)
            {
                try { Write(ctx, Fail("خطای داخلی سرویس: " + ex.Message)); }
                catch { /* ارتباط قطع شده */ }
            }
            finally { sw.Stop(); }
        }

        // ------------------------------------------------------------ Ping

        private void Ping(HttpContext ctx)
        {
            try
            {
                using (var cn = new SqlConnection(ConnectionString(null)))
                {
                    cn.Open();
                    using (var cmd = cn.CreateCommand())
                    {
                        cmd.CommandText = "SELECT @@SERVERNAME, @@VERSION, DB_NAME()";
                        cmd.CommandTimeout = 15;
                        using (var r = cmd.ExecuteReader())
                        {
                            if (!r.Read()) { Write(ctx, Fail("پاسخی از SQL Server نرسید")); return; }
                            var o = new Dictionary<string, object>
                            {
                                { "ok", true },
                                { "service", "MReportService" },
                                { "server", Str(r, 0) },
                                { "version", FirstLine(Str(r, 1)) },
                                { "database", Str(r, 2) },
                                { "utc", DateTime.UtcNow.ToString("o") },
                                { "error", null },
                            };
                            Write(ctx, o);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Write(ctx, Fail("اتصال به SQL Server ناموفق: " + ex.Message));
            }
        }

        // ------------------------------------------------------------ Query

        private void Query(HttpContext ctx)
        {
            string raw;
            using (var sr = new StreamReader(ctx.Request.InputStream, Encoding.UTF8))
                raw = sr.ReadToEnd();

            if (string.IsNullOrWhiteSpace(raw)) { Write(ctx, Fail("بدنهٔ درخواست خالی است")); return; }

            Dictionary<string, object> req;
            try
            {
                var js = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
                req = js.DeserializeObject(raw) as Dictionary<string, object>;
            }
            catch (Exception ex) { Write(ctx, Fail("JSON درخواست قابل خواندن نیست: " + ex.Message)); return; }

            if (req == null) { Write(ctx, Fail("بدنهٔ درخواست یک آبجکت JSON نیست")); return; }

            var sqlIn = Get(req, "sql");
            var dbIn = Get(req, "database");
            var maxRows = Clamp(GetInt(req, "maxRows", DEFAULT_MAX_ROWS), 1, HARD_MAX_ROWS);
            var timeout = Clamp(GetInt(req, "timeoutSec", DEFAULT_TIMEOUT_SEC), 1, HARD_TIMEOUT_SEC);

            var paramList = new List<object>();
            var pa = req.ContainsKey("params") ? req["params"] as object[] : null;
            if (pa != null)
                foreach (var x in pa) paramList.Add(x);

            string problem;
            var sql = ValidateReadOnly(sqlIn, out problem);
            if (sql == null) { Write(ctx, Fail(problem)); return; }

            sql = BindPlaceholders(sql);

            var sw = Stopwatch.StartNew();
            var columns = new List<string>();
            var rows = new List<object[]>();
            var truncated = false;

            try
            {
                using (var cn = new SqlConnection(ConnectionString(dbIn)))
                {
                    cn.Open();
                    using (var cmd = cn.CreateCommand())
                    {
                        cmd.CommandText = sql;
                        cmd.CommandTimeout = timeout;
                        cmd.CommandType = CommandType.Text;

                        for (var i = 0; i < paramList.Count; i++)
                            AddParam(cmd, "@p" + i, paramList[i]);

                        using (var r = cmd.ExecuteReader())
                        {
                            var n = r.FieldCount;
                            for (var i = 0; i < n; i++) columns.Add(r.GetName(i));

                            while (r.Read())
                            {
                                if (rows.Count >= maxRows) { truncated = true; break; }
                                var row = new object[n];
                                for (var i = 0; i < n; i++)
                                    row[i] = r.IsDBNull(i) ? null : (object)Format(r.GetValue(i));
                                rows.Add(row);
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                Write(ctx, Fail("خطای SQL Server (" + ex.Number + "): " + ex.Message));
                return;
            }
            catch (Exception ex) { Write(ctx, Fail(ex.Message)); return; }

            sw.Stop();
            Write(ctx, new Dictionary<string, object>
            {
                { "ok", true },
                { "columns", columns.ToArray() },
                { "rows", ToArrays(rows) },
                { "truncated", truncated },
                { "rowCount", rows.Count },
                { "elapsedMs", sw.ElapsedMilliseconds },
                { "error", null },
            });
        }

        // ------------------------------------------------------------ فقط-خواندنی

        private static string ValidateReadOnly(string raw, out string problem)
        {
            problem = null;
            if (string.IsNullOrWhiteSpace(raw)) { problem = "کوئری خالی است"; return null; }

            var body = raw.Trim().TrimEnd(';').Trim();
            if (body.IndexOf(';') >= 0) { problem = "چند دستور در یک کوئری مجاز نیست"; return null; }

            var head = body.Split(' ')[0].ToUpperInvariant();
            if (head != "SELECT" && head != "WITH") { problem = "فقط SELECT یا WITH مجاز است"; return null; }

            var upper = body.ToUpperInvariant();
            foreach (var kw in Forbidden)
                if (Regex.IsMatch(upper, @"(?<![A-Z0-9_#])" + kw + @"(?![A-Z0-9_])"))
                {
                    problem = "دستور «" + kw + "» در حالت فقط-خواندنی مجاز نیست";
                    return null;
                }
            return body;
        }

        /// <summary>
        /// `?` (سبک JDBC) → `@p0`, `@p1`, … — SQL Server `?` را قبول نمی‌کند.
        /// `?`های داخل رشتهٔ لیترال دست‌نخورده می‌مانند و `''` escape است.
        /// </summary>
        private static string BindPlaceholders(string sql)
        {
            if (string.IsNullOrEmpty(sql) || sql.IndexOf('?') < 0) return sql;
            var sb = new StringBuilder(sql.Length + 16);
            var inStr = false; var n = 0;
            for (var i = 0; i < sql.Length; i++)
            {
                var c = sql[i];
                if (c == '\'')
                {
                    if (inStr && i + 1 < sql.Length && sql[i + 1] == '\'') { sb.Append("''"); i++; continue; }
                    inStr = !inStr; sb.Append(c);
                }
                else if (c == '?' && !inStr) { sb.Append("@p").Append(n); n++; }
                else sb.Append(c);
            }
            return sb.ToString();
        }

        // ------------------------------------------------------------ اتصال

        private static string ConnectionString(string requestedDb)
        {
            var named = ConfigurationManager.ConnectionStrings["MReportDb"];
            if (named != null && !string.IsNullOrWhiteSpace(named.ConnectionString))
                return named.ConnectionString;

            var server = ConfigurationManager.AppSettings["SqlServer"] ?? ".";
            var port = ConfigurationManager.AppSettings["SqlPort"];
            var db = ConfigurationManager.AppSettings["SqlDatabase"] ?? "Atiran2";

            if (!string.IsNullOrWhiteSpace(requestedDb) &&
                Regex.IsMatch(requestedDb, @"^[A-Za-z0-9_]{1,128}$")) db = requestedDb;

            var dataSource = string.IsNullOrWhiteSpace(port) ? server : server + "," + port;
            var user = ConfigurationManager.AppSettings["SqlUser"];
            var pwd = ConfigurationManager.AppSettings["SqlPassword"];

            var sb = "data source=" + dataSource + ";initial catalog=" + db +
                     ";packet size=4096;Connect Timeout=15;";
            if (!string.IsNullOrWhiteSpace(user)) sb += "user id=" + user + ";password=" + pwd + ";";
            else sb += "Integrated Security=SSPI;";
            return sb;
        }

        private static bool KeyOk(HttpContext ctx)
        {
            var expected = ConfigurationManager.AppSettings["ApiKey"];
            if (string.IsNullOrWhiteSpace(expected)) return true;
            var got = ctx.Request.Headers["X-MReport-Key"];
            return string.Equals(got, expected, StringComparison.Ordinal);
        }

        // ------------------------------------------------------------ ابزارها

        private static object[][] ToArrays(List<object[]> rows)
        {
            var outp = new object[rows.Count][];
            for (var i = 0; i < rows.Count; i++) outp[i] = rows[i];
            return outp;
        }

        private static Dictionary<string, object> Fail(string message)
        {
            return new Dictionary<string, object>
            {
                { "ok", false },
                { "columns", new string[0] },
                { "rows", new object[0][] },
                { "truncated", false },
                { "rowCount", 0 },
                { "elapsedMs", 0 },
                { "error", message },
            };
        }

        private static void Write(HttpContext ctx, object payload)
        {
            var js = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
            ctx.Response.Write(js.Serialize(payload));
        }

        /// <summary>
        /// نوع SqlParameter از نوع واقعی مقدار JSON گرفته می‌شود، نه حدس.
        ///
        /// چرا مهم است: SQL Server در `OFFSET @p ROWS` و `FETCH NEXT @p ROWS`
        /// فقط عدد صحیح می‌پذیرد. اگر همان مقدار را NVarChar ببندیم، خطای
        /// «The number of rows provided for a OFFSET clause must be an integer»
        /// می‌دهد و صفحه‌بندی همهٔ جدول‌ها از کار می‌افتد.
        ///
        /// JavaScriptSerializer عدد صحیح JSON را int/long و اعشاری را decimal
        /// برمی‌گرداند، رشته را string و بولین را bool — پس همین‌جا نوع قطعی است.
        /// </summary>
        private static void AddParam(SqlCommand cmd, string name, object v)
        {
            if (v == null)
            {
                var pn = cmd.Parameters.Add(name, SqlDbType.NVarChar, 4000);
                pn.Value = DBNull.Value;
                return;
            }
            if (v is bool)
            {
                cmd.Parameters.Add(name, SqlDbType.Bit).Value = v;
                return;
            }
            if (v is int || v is long || v is short || v is byte || v is uint || v is ulong)
            {
                cmd.Parameters.Add(name, SqlDbType.BigInt)
                   .Value = Convert.ToInt64(v, CultureInfo.InvariantCulture);
                return;
            }
            if (v is decimal || v is double || v is float)
            {
                cmd.Parameters.Add(name, SqlDbType.Decimal)
                   .Value = Convert.ToDecimal(v, CultureInfo.InvariantCulture);
                return;
            }
            // بقیه (از جمله string) — متن
            var p = cmd.Parameters.Add(name, SqlDbType.NVarChar, 4000);
            p.Value = Convert.ToString(v, CultureInfo.InvariantCulture) ?? (object)DBNull.Value;
        }

        private static string Get(Dictionary<string, object> d, string k)
        {
            if (!d.ContainsKey(k) || d[k] == null) return null;
            return Convert.ToString(d[k], CultureInfo.InvariantCulture);
        }

        private static int GetInt(Dictionary<string, object> d, string k, int fallback)
        {
            if (!d.ContainsKey(k) || d[k] == null) return fallback;
            int v;
            return int.TryParse(Convert.ToString(d[k], CultureInfo.InvariantCulture), out v) ? v : fallback;
        }

        private static int Clamp(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

        private static string Str(IDataRecord r, int i) { return r.IsDBNull(i) ? "" : r.GetValue(i).ToString(); }

        private static string FirstLine(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            var i = s.IndexOf('\n');
            return (i < 0 ? s : s.Substring(0, i)).Trim();
        }

        /// <summary>همهٔ مقدارها به متن — null حفظ می‌شود؛ سمت اپ دقیقاً همین را می‌خواند</summary>
        private static string Format(object v)
        {
            if (v == null || v == DBNull.Value) return null;
            if (v is DateTime) return ((DateTime)v).ToString("yyyy-MM-dd HH:mm:ss");
            if (v is byte[]) return Convert.ToBase64String((byte[])v);
            if (v is bool) return ((bool)v) ? "1" : "0";
            return Convert.ToString(v, CultureInfo.InvariantCulture);
        }
    }
}
