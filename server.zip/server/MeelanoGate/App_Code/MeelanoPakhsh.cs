using System;

namespace Meelano.Gate
{
    /// <summary>
    /// دروازهٔ نقش **مامور پخش** — سرویس MeelanoGate.
    ///
    /// مسیر: /MeelanoPakhsh.ashx
    ///
    /// این نقش فقط می‌تواند جدول‌های فهرست زیر را بخواند. محدودیت سمت
    /// سرور اجبار می‌شود، نه فقط در رابط کاربری پنهان شود — یعنی حتی با
    /// داشتن کلید دسترسی، کوئری روی جدول بیرون از این فهرست ۴۰۳ می‌گیرد.
    ///
    /// منبع فهرست: جداول واقعی سیستم ServiceTozie که در
    /// `docs/unified-role-architecture.md` مستند شده است.
    /// </summary>
    public class MeelanoPakhsh : MeelanoCore
    {
        public override string RoleId { get { return "distributor"; } }

        public override string RoleFaName { get { return "مامور پخش"; } }

        public override string[] AllowedTables
        {
            get
            {
                return new string[]
                {
                    "worker",
                    "cars",
                    "visitors",
                    "CUSTOMERS",
                    "custgroup",
                    "anbars",
                    "inventory",
                    "inventory_anbars",
                    "Inventory_Anbars_PS",
                    "kagroup",
                    "sailfact",
                    "sailfact_pish",
                    "subsailfact",
                    "subsailfact_pish",
                    "backsail_pish",
                    "subBackSail_pish",
                    "taraz",
                    "PishDaryaft",
                    "PishDaryaftGetCheck",
                    "PishDaryaftPos",
                    "BANK",
                    "BANK_NAME",
                    "BankPos",
                    "ReasonsForNonDeliveryDistribution",
                    "ReasonForRevocation",
                    "TaeediehErsalFactor",
                    "UnTaeediehErsalFactor",
                    "DeviceDistribution",
                    "DeviceLocationDistribution",
                    "DeviceSettingDistribution",
                    "sys_wor",
                    "sys_vis",
                    "sys_kal",
                    "sys_use",
                    "sys_users",
                    "osystems",
                    "overal_setting",
                };
            }
        }
    }
}
