using System;

namespace Meelano.Gate
{
    /// <summary>
    /// دروازهٔ نقش **ویزیتور** — سرویس MeelanoGate.
    ///
    /// مسیر: /MeelanoVizit.ashx
    ///
    /// این نقش فقط می‌تواند جدول‌های فهرست زیر را بخواند. محدودیت سمت
    /// سرور اجبار می‌شود، نه فقط در رابط کاربری پنهان شود — یعنی حتی با
    /// داشتن کلید دسترسی، کوئری روی جدول بیرون از این فهرست ۴۰۳ می‌گیرد.
    ///
    /// منبع فهرست: جداول واقعی سیستم AtiranHamrah که در
    /// `docs/unified-role-architecture.md` مستند شده است.
    /// </summary>
    public class MeelanoVizit : MeelanoCore
    {
        public override string RoleId { get { return "visitor"; } }

        public override string RoleFaName { get { return "ویزیتور"; } }

        public override string[] AllowedTables
        {
            get
            {
                return new string[]
                {
                    "visitor",
                    "Visit",
                    "vis_rdf",
                    "masir",
                    "MasirDay",
                    "regions",
                    "CITYS",
                    "Province",
                    "CUSTOMER",
                    "cust_act",
                    "custgroup",
                    "TabletCustomer",
                    "inventory",
                    "inventory_anbars",
                    "kagroup",
                    "ka_image",
                    "anbar",
                    "forosh_price",
                    "promotion",
                    "getchk",
                    "BANK",
                    "BANK_NAME",
                    "svcGetBanks",
                    "PishDaryaft",
                    "PishDaryaftGetCheck",
                    "PishDaryaftMultiFactor",
                    "PishDaryaftPos",
                    "SaleFactTasvieh",
                    "sailfact",
                    "sailfact_pish",
                    "subsailfact",
                    "subsailfact_pish",
                    "prize_table",
                    "prize_table_group",
                    "prizePercent",
                    "prizePercentGroup",
                    "sys_vis",
                    "sys_cus",
                    "sys_anb",
                    "sys_kal",
                    "osystems",
                    "overal_setting",
                    "Device",
                    "DeviceLocation",
                    "DeviceMessages",
                    "DeviceSettings",
                    "Company",
                    "LimitedService",
                    "VWForushKhale",
                    "VW_AllBargashti",
                    "VW_FORUSH_RizAghlam_Nakhales",
                    "VW_Forush_DarBazeZamani",
                    "VW_InventoryAnbars",
                };
            }
        }
    }
}
