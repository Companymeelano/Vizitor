using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Script.Serialization;

namespace Meelano.Gate
{
    /// <summary>
    /// هستهٔ مشترک دروازه‌های نقش‌محور **MeelanoGate**.
    ///
    /// چرا هر نقش یک فایل جدا دارد:
    ///   پنهان‌کردن بخش‌ها در رابط کاربری، دسترسی را نمی‌بندد — فقط نشان
    ///   نمی‌دهد. هر کسی که آدرس سرویس و کلید را داشته باشد می‌تواند هر
    ///   کوئری‌ای بزند. این‌جا محدودیت سمت سرور اجبار می‌شود: هر نقش یک
    ///   endpoint جدا دارد و فقط جدول‌های همان نقش را می‌تواند بخواند.
    ///
    /// چرا `IHttpHandler` و نه Web API:
    ///   بدون وابستگی NuGet و بدون مرحلهٔ Build. ASP.NET همین فایل‌ها را از
    ///   `App_Code` در زمان اجرا کامپایل می‌کند؛ نصب یعنی «کپی پوشه + ساخت
    ///   سایت IIS».
    ///
    /// امنیت (لایه‌به‌لایه):
    ///   ۱) کلید دسترسی اجباری — بدون آن ۴۰۱
    ///   ۲) فقط SELECT/WITH — ۱۹ کلیدواژهٔ نوشتاری رد می‌شود
    ///   ۳) یک دستور در هر درخواست (`;` ممنوع)
    ///   ۴) **محدودهٔ جدول نقش** — هر جدولی بیرون فهرست مجاز آن نقش رد می‌شود
    ///   ۵) پارامترها همیشه SqlParameter
    ///   ۶) سقف سخت ۵۰۰۰ سطر / ۱۲۰ ثانیه
    /// </summary>
    public abstract class MeelanoCore : IHttpHandler
    {
        private const int HARD_MAX_ROWS = 5000;
        private const int HARD_TIMEOUT_SEC = 120;
        private const int DEFAULT_MAX_ROWS = 1000;
        private const int DEFAULT_TIMEOUT_SEC = 45;

        /// <summary>شناسهٔ ماشین‌خوان نقش — همان مقداری که اپ می‌فرستد</summary>
        public abstract string RoleId { get; }

        /// <summary>نام فارسی نقش — در پاسخ Ping برمی‌گردد تا اپ مطمئن شود</summary>
        public abstract string RoleFaName { get; }

        /// <summary>
        /// جدول‌هایی که این نقش اجازهٔ خواندنشان را دارد.
        /// `null` یعنی بدون محدودیت (نقش مدیریت).
        /// </summary>
        public abstract string[] AllowedTables { get; }

        public bool IsReusable { get { return true; } }

        private static readonly string[] Forbidden =
        {
            "INSERT", "UPDATE", "DELETE", "DROP", "ALTER", "TRUNCATE", "MERGE",
            "EXEC", "EXECUTE", "CREATE", "GRANT", "REVOKE", "DENY",
            "BACKUP", "RESTORE", "SHUTDOWN", "KILL",
            "OPENROWSET", "OPENDATASOURCE",
        };

        /// <summary>
        /// نماهای کاتالوگ سیستم — برای هر نقش مجازند.
        ///
        /// چرا: اپ برای ساخت «نمای کلی» و شناخت ستون‌های جدول به این‌ها
        /// کوئری می‌زند (sys.tables، sys.schemas، sys.partitions،
        /// INFORMATION_SCHEMA.*). بدون آن‌ها صفحهٔ اصلی هر نقش خالی می‌ماند.
        /// این‌ها فقط فراداده می‌دهند، نه دادهٔ کسب‌وکار.
        /// </summary>
        private static readonly string[] SystemCatalog =
        {
            "TABLES", "COLUMNS", "VIEWS", "VIEW_COLUMN_USAGE", "KEY_COLUMN_USAGE",
            "TABLE_CONSTRAINTS", "ROUTINES", "PARAMETERS", "SCHEMATA",
            "tables", "schemas", "partitions", "master_files", "objects",
            "columns", "indexes", "index_columns", "types", "database_files",
            "dm_db_partition_stats", "allocation_units",
        };

        private static readonly string[] StopWords =
        {
            "WHERE", "GROUP", "ORDER", "HAVING", "UNION", "EXCEPT", "INTERSECT",
            "INNER", "LEFT", "RIGHT", "FULL", "CROSS", "OUTER", "APPLY", "JOIN",
            "ON", "OPTION", "FOR", "SELECT", "SET", "PIVOT", "UNPIVOT",
            "INSERT", "UPDATE", "DELETE", "VALUES", "TOP", "AS",
        };

        // ------------------------------------------------------------ ورودی

        public void ProcessRequest(HttpContext ctx)
        {
            try
            {
                ctx.Response.ContentType = "application/json; charset=utf-8";
                ctx.Response.Cache.SetNoStore();

                var method = (ctx.Request.HttpMethod ?? "GET").ToUpperInvariant();
                if (method == "OPTIONS") { ctx.Response.StatusCode = 204; return; }

                if (!KeyOk(ctx))
                {
                    ctx.Response.StatusCode = 401;
                    Write(ctx, Fail("کلید دسترسی نامعتبر است"));
                    return;
                }

                if (method == "GET") { Ping(ctx); return; }
                if (method != "POST")
                {
                    ctx.Response.StatusCode = 405;
                    Write(ctx, Fail("فقط GET و POST پشتیبانی می‌شود"));
                    return;
                }

                Query(ctx);
            }
            catch (Exception ex)
            {
                try { Write(ctx, Fail("خطای داخلی سرویس: " + ex.Message)); }
                catch { /* ارتباط قطع شده */ }
            }
        }

        // ------------------------------------------------------------ Ping

        private void Ping(HttpContext ctx)
        {
            try
            {
                using (var cn = new SqlConnection(ConnectionString(null)))
                {
                    cn.Open();
                    using (var cmd = cn.CreateCommand())
                    {
                        cmd.CommandText = "SELECT @@SERVERNAME, @@VERSION, DB_NAME()";
                        cmd.CommandTimeout = 15;
                        using (var r = cmd.ExecuteReader())
                        {
                            if (!r.Read()) { Write(ctx, Fail("پاسخی از SQL Server نرسید")); return; }
                            var o = new Dictionary<string, object>
                            {
                                { "ok", true },
                                { "service", "MeelanoGate" },
                                { "role", RoleId },
                                { "roleFa", RoleFaName },
                                { "server", Str(r, 0) },
                                { "version", FirstLine(Str(r, 1)) },
                                { "database", Str(r, 2) },
                                { "utc", DateTime.UtcNow.ToString("o") },
                                { "error", null },
                            };
                            Write(ctx, o);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Write(ctx, Fail("اتصال به SQL Server ناموفق: " + ex.Message));
            }
        }

        // ------------------------------------------------------------ Query

        private void Query(HttpContext ctx)
        {
            string raw;
            using (var sr = new StreamReader(ctx.Request.InputStream, Encoding.UTF8))
                raw = sr.ReadToEnd();

            if (string.IsNullOrWhiteSpace(raw)) { Write(ctx, Fail("بدنهٔ درخواست خالی است")); return; }

            Dictionary<string, object> req;
            try
            {
                var js = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
                req = js.DeserializeObject(raw) as Dictionary<string, object>;
            }
            catch (Exception ex) { Write(ctx, Fail("JSON درخواست قابل خواندن نیست: " + ex.Message)); return; }

            if (req == null) { Write(ctx, Fail("بدنهٔ درخواست یک آبجکت JSON نیست")); return; }

            var sqlIn = Get(req, "sql");
            var dbIn = Get(req, "database");
            var maxRows = Clamp(GetInt(req, "maxRows", DEFAULT_MAX_ROWS), 1, HARD_MAX_ROWS);
            var timeout = Clamp(GetInt(req, "timeoutSec", DEFAULT_TIMEOUT_SEC), 1, HARD_TIMEOUT_SEC);

            var paramList = new List<object>();
            var pa = req.ContainsKey("params") ? req["params"] as object[] : null;
            if (pa != null) foreach (var x in pa) paramList.Add(x);

            string problem;
            var sql = ValidateReadOnly(sqlIn, out problem);
            if (sql == null) { Write(ctx, Fail(problem)); return; }

            // ---- محدودهٔ جدول نقش: لایهٔ امنیتی اصلی این سرویس ----
            if (!TablesAllowed(sql, out problem))
            {
                ctx.Response.StatusCode = 403;
                Write(ctx, Fail(problem));
                return;
            }

            sql = BindPlaceholders(sql);

            var sw = Stopwatch.StartNew();
            var columns = new List<string>();
            var rows = new List<object[]>();
            var truncated = false;

            try
            {
                using (var cn = new SqlConnection(ConnectionString(dbIn)))
                {
                    cn.Open();
                    using (var cmd = cn.CreateCommand())
                    {
                        cmd.CommandText = sql;
                        cmd.CommandTimeout = timeout;
                        cmd.CommandType = CommandType.Text;

                        for (var i = 0; i < paramList.Count; i++)
                            AddParam(cmd, "@p" + i, paramList[i]);

                        using (var r = cmd.ExecuteReader())
                        {
                            var n = r.FieldCount;
                            for (var i = 0; i < n; i++) columns.Add(r.GetName(i));

                            while (r.Read())
                            {
                                if (rows.Count >= maxRows) { truncated = true; break; }
                                var row = new object[n];
                                for (var i = 0; i < n; i++)
                                    row[i] = r.IsDBNull(i) ? null : (object)Format(r.GetValue(i));
                                rows.Add(row);
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                Write(ctx, Fail("خطای SQL Server (" + ex.Number + "): " + ex.Message));
                return;
            }
            catch (Exception ex) { Write(ctx, Fail(ex.Message)); return; }

            sw.Stop();
            Write(ctx, new Dictionary<string, object>
            {
                { "ok", true },
                { "role", RoleId },
                { "columns", columns.ToArray() },
                { "rows", ToArrays(rows) },
                { "truncated", truncated },
                { "rowCount", rows.Count },
                { "elapsedMs", sw.ElapsedMilliseconds },
                { "error", null },
            });
        }

        // -------------------------------------------- محدودهٔ جدول نقش

        /// <summary>
        /// همهٔ جدول‌هایی که کوئری به آن‌ها اشاره می‌کند باید در فهرست مجاز
        /// این نقش باشند. این همان چیزی است که «دسترسی نداشتن به بخش بی‌ربط»
        /// را واقعاً enforce می‌کند، نه فقط پنهانش می‌کند.
        ///
        /// صداقت دربارهٔ محدودیت: این یک پیمایش گرمری کامل نیست — یک
        /// پارسر SQL واقعی نیست. هدفش defence-in-depth روی کلید دسترسی است،
        /// نه جایگزینی برای آن. حالت‌های پوشش‌داده: FROM/JOIN ساده، فهرست
        /// جدا‌شده با کاما، `schema.table`، نام داخل `[کروشه]`، و CTE.
        /// </summary>
        private bool TablesAllowed(string sql, out string problem)
        {
            problem = null;

            // سوپاپ اطمینان: اگر در استقرار واقعی جدولی از فهرست جا افتاده
            // بود، می‌توان با EnforceTableScope=false موقتاً محدودیت را
            // برداشت تا سرویس از کار نیفتد. پیش‌فرض «روشن» است — خاموش‌کردنش
            // یک تصمیم آگاهانه است، نه وضعیت پیش‌فرض.
            var enforce = ConfigurationManager.AppSettings["EnforceTableScope"];
            if (string.Equals(enforce, "false", StringComparison.OrdinalIgnoreCase))
                return true;

            var allowed = AllowedTables;
            if (allowed == null) return true;   // نقش مدیریت — بدون محدودیت

            var clean = StripLiterals(sql);
            var ctes = ExtractCtes(clean);
            var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var t in allowed) set.Add(t);

            foreach (var t in ExtractTables(clean))
            {
                if (ctes.Contains(t)) continue;      // نام CTE، نه جدول واقعی
                if (set.Contains(t)) continue;
                if (IsSystemCatalog(t)) continue;    // فرادادهٔ سیستم، نه داده
                problem = "نقش «" + RoleFaName + "» به جدول «" + t + "» دسترسی ندارد";
                return false;
            }
            return true;
        }

        private static readonly Regex FromJoin =
            new Regex(@"(?<![A-Za-z0-9_])(FROM|JOIN)(?![A-Za-z0-9_])",
                      RegexOptions.IgnoreCase | RegexOptions.Compiled);

        private static readonly Regex WordRe =
            new Regex(@"^[A-Za-z_][A-Za-z0-9_]*", RegexOptions.Compiled);

        private static readonly Regex CteRe =
            new Regex(@"(?<![A-Za-z0-9_])(?:WITH|,)\s*(\[?[A-Za-z_][A-Za-z0-9_]*\]?)\s+AS\s*\(",
                      RegexOptions.IgnoreCase | RegexOptions.Compiled);

        /// <summary>رشته‌های لیترال و کامنت‌ها را حذف می‌کند تا نام جدولِ داخل متن شمرده نشود</summary>
        private static string StripLiterals(string sql)
        {
            var sb = new StringBuilder(sql.Length);
            var i = 0;
            while (i < sql.Length)
            {
                var c = sql[i];
                if (c == '\'')
                {
                    i++;
                    while (i < sql.Length)
                    {
                        if (sql[i] == '\'')
                        {
                            if (i + 1 < sql.Length && sql[i + 1] == '\'') { i += 2; continue; }
                            i++; break;
                        }
                        i++;
                    }
                    sb.Append(' ');
                    continue;
                }
                if (c == '-' && i + 1 < sql.Length && sql[i + 1] == '-')
                {
                    while (i < sql.Length && sql[i] != '\n') i++;
                    sb.Append(' ');
                    continue;
                }
                if (c == '/' && i + 1 < sql.Length && sql[i + 1] == '*')
                {
                    i += 2;
                    while (i + 1 < sql.Length && !(sql[i] == '*' && sql[i + 1] == '/')) i++;
                    i = Math.Min(i + 2, sql.Length);
                    sb.Append(' ');
                    continue;
                }
                sb.Append(c);
                i++;
            }
            return sb.ToString();
        }

        private static HashSet<string> ExtractCtes(string clean)
        {
            var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (Match m in CteRe.Matches(clean))
                set.Add(m.Groups[1].Value.Trim('[', ']'));
            return set;
        }

        private static List<string> ExtractTables(string clean)
        {
            var names = new List<string>();
            foreach (Match m in FromJoin.Matches(clean))
                CollectFromList(clean, m.Index + m.Length, names);
            return names;
        }

        /// <summary>
        /// از جایگاه بعد از FROM/JOIN یک فهرست جدا‌شده با کاما می‌خواند:
        /// `FROM a, dbo.b x, [c] AS y` → a, b, c
        /// زیرکوئری `FROM (SELECT …)` اینجا متوقف می‌شود؛ FROMهای داخلش
        /// خودشان جداگانه پیدا می‌شوند.
        /// </summary>
        private static void CollectFromList(string s, int start, List<string> outNames)
        {
            var i = start;
            while (true)
            {
                i = SkipWs(s, i);
                if (i >= s.Length) return;
                if (s[i] == '(') return;              // زیرکوئری

                var name = ReadIdent(s, ref i);
                if (name == null) return;

                i = SkipWs(s, i);
                if (i < s.Length && s[i] == '.')       // schema.table → فقط table
                {
                    i = SkipWs(s, i + 1);
                    var t = ReadIdent(s, ref i);
                    if (t != null) name = t;
                    i = SkipWs(s, i);
                }
                outNames.Add(name);

                // نام مستعار اختیاری — اگر کلمهٔ کلیدی نبود، ردش کن
                var save = i;
                var maybe = ReadIdent(s, ref i);
                if (maybe != null && IsStopWord(maybe)) i = save;

                i = SkipWs(s, i);
                if (i < s.Length && s[i] == ',') { i++; continue; }
                return;
            }
        }

        private static int SkipWs(string s, int i)
        {
            while (i < s.Length && char.IsWhiteSpace(s[i])) i++;
            return i;
        }

        private static string ReadIdent(string s, ref int i)
        {
            if (i >= s.Length) return null;
            if (s[i] == '[')
            {
                var end = s.IndexOf(']', i);
                if (end < 0) return null;
                var v = s.Substring(i + 1, end - i - 1);
                i = end + 1;
                return v;
            }
            var m = WordRe.Match(s, i);
            if (!m.Success || m.Index != i) return null;
            i = m.Index + m.Length;
            return m.Value;
        }

        private static bool IsSystemCatalog(string t)
        {
            foreach (var k in SystemCatalog)
                if (string.Equals(k, t, StringComparison.OrdinalIgnoreCase)) return true;
            return false;
        }

        private static bool IsStopWord(string w)
        {
            var u = w.ToUpperInvariant();
            foreach (var k in StopWords) if (k == u) return true;
            return false;
        }

        // -------------------------------------------- فقط-خواندنی

        private static string ValidateReadOnly(string raw, out string problem)
        {
            problem = null;
            if (string.IsNullOrWhiteSpace(raw)) { problem = "کوئری خالی است"; return null; }

            var body = raw.Trim().TrimEnd(';').Trim();
            if (body.IndexOf(';') >= 0) { problem = "چند دستور در یک کوئری مجاز نیست"; return null; }

            var head = body.Split(' ')[0].ToUpperInvariant();
            if (head != "SELECT" && head != "WITH") { problem = "فقط SELECT یا WITH مجاز است"; return null; }

            var upper = body.ToUpperInvariant();
            foreach (var kw in Forbidden)
                if (Regex.IsMatch(upper, @"(?<![A-Z0-9_#])" + kw + @"(?![A-Z0-9_])"))
                {
                    problem = "دستور «" + kw + "» در حالت فقط-خواندنی مجاز نیست";
                    return null;
                }
            return body;
        }

        /// <summary>`?` (سبک JDBC) → `@p0`, `@p1`, … — SQL Server `?` را قبول نمی‌کند</summary>
        private static string BindPlaceholders(string sql)
        {
            if (string.IsNullOrEmpty(sql) || sql.IndexOf('?') < 0) return sql;
            var sb = new StringBuilder(sql.Length + 16);
            var inStr = false; var n = 0;
            for (var i = 0; i < sql.Length; i++)
            {
                var c = sql[i];
                if (c == '\'')
                {
                    if (inStr && i + 1 < sql.Length && sql[i + 1] == '\'') { sb.Append("''"); i++; continue; }
                    inStr = !inStr; sb.Append(c);
                }
                else if (c == '?' && !inStr) { sb.Append("@p").Append(n); n++; }
                else sb.Append(c);
            }
            return sb.ToString();
        }

        // -------------------------------------------- اتصال

        private static string ConnectionString(string requestedDb)
        {
            var named = ConfigurationManager.ConnectionStrings["MeelanoDb"];
            if (named != null && !string.IsNullOrWhiteSpace(named.ConnectionString))
                return named.ConnectionString;

            var server = ConfigurationManager.AppSettings["SqlServer"] ?? ".";
            var port = ConfigurationManager.AppSettings["SqlPort"];
            var db = ConfigurationManager.AppSettings["SqlDatabase"] ?? "Atiran2";

            if (!string.IsNullOrWhiteSpace(requestedDb) &&
                Regex.IsMatch(requestedDb, @"^[A-Za-z0-9_]{1,128}$")) db = requestedDb;

            var dataSource = string.IsNullOrWhiteSpace(port) ? server : server + "," + port;
            var user = ConfigurationManager.AppSettings["SqlUser"];
            var pwd = ConfigurationManager.AppSettings["SqlPassword"];

            var sb = "data source=" + dataSource + ";initial catalog=" + db +
                     ";packet size=4096;Connect Timeout=15;";
            if (!string.IsNullOrWhiteSpace(user)) sb += "user id=" + user + ";password=" + pwd + ";";
            else sb += "Integrated Security=SSPI;";
            return sb;
        }

        /// <summary>
        /// کلید دسترسی **اجباری** است. برخلاف سرویس قبلی، کلید خالی به معنی
        /// «باز» نیست — installer هم بدون کلید نصب نمی‌کند.
        /// هر دو نام هدر پذیرفته می‌شود تا اپ قدیمی هم کار کند.
        /// </summary>
        private static bool KeyOk(HttpContext ctx)
        {
            var expected = ConfigurationManager.AppSettings["ApiKey"];
            if (string.IsNullOrWhiteSpace(expected)) return false;

            var got = ctx.Request.Headers["X-Meelano-Key"];
            if (string.Equals(got, expected, StringComparison.Ordinal)) return true;

            got = ctx.Request.Headers["X-MReport-Key"];
            return string.Equals(got, expected, StringComparison.Ordinal);
        }

        // -------------------------------------------- ابزارها

        private static object[][] ToArrays(List<object[]> rows)
        {
            var outp = new object[rows.Count][];
            for (var i = 0; i < rows.Count; i++) outp[i] = rows[i];
            return outp;
        }

        private static Dictionary<string, object> Fail(string message)
        {
            return new Dictionary<string, object>
            {
                { "ok", false },
                { "columns", new string[0] },
                { "rows", new object[0][] },
                { "truncated", false },
                { "rowCount", 0 },
                { "elapsedMs", 0 },
                { "error", message },
            };
        }

        private static void Write(HttpContext ctx, object payload)
        {
            var js = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
            ctx.Response.Write(js.Serialize(payload));
        }

        /// <summary>
        /// نوع SqlParameter از نوع واقعی مقدار JSON گرفته می‌شود، نه حدس.
        /// SQL Server در `OFFSET @p ROWS` فقط عدد صحیح می‌پذیرد؛ بستن همان
        /// مقدار به‌صورت NVarChar صفحه‌بندی را می‌شکند.
        /// </summary>
        private static void AddParam(SqlCommand cmd, string name, object v)
        {
            if (v == null)
            {
                var pn = cmd.Parameters.Add(name, SqlDbType.NVarChar, 4000);
                pn.Value = DBNull.Value;
                return;
            }
            if (v is bool) { cmd.Parameters.Add(name, SqlDbType.Bit).Value = v; return; }
            if (v is int || v is long || v is short || v is byte || v is uint || v is ulong)
            {
                cmd.Parameters.Add(name, SqlDbType.BigInt)
                   .Value = Convert.ToInt64(v, CultureInfo.InvariantCulture);
                return;
            }
            if (v is decimal || v is double || v is float)
            {
                cmd.Parameters.Add(name, SqlDbType.Decimal)
                   .Value = Convert.ToDecimal(v, CultureInfo.InvariantCulture);
                return;
            }
            var p = cmd.Parameters.Add(name, SqlDbType.NVarChar, 4000);
            p.Value = Convert.ToString(v, CultureInfo.InvariantCulture) ?? (object)DBNull.Value;
        }

        private static string Get(Dictionary<string, object> d, string k)
        {
            if (!d.ContainsKey(k) || d[k] == null) return null;
            return Convert.ToString(d[k], CultureInfo.InvariantCulture);
        }

        private static int GetInt(Dictionary<string, object> d, string k, int fallback)
        {
            if (!d.ContainsKey(k) || d[k] == null) return fallback;
            int v;
            return int.TryParse(Convert.ToString(d[k], CultureInfo.InvariantCulture), out v) ? v : fallback;
        }

        private static int Clamp(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

        private static string Str(IDataRecord r, int i) { return r.IsDBNull(i) ? "" : r.GetValue(i).ToString(); }

        private static string FirstLine(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            var i = s.IndexOf('\n');
            return (i < 0 ? s : s.Substring(0, i)).Trim();
        }

        /// <summary>همهٔ مقدارها به متن — null حفظ می‌شود؛ سمت اپ دقیقاً همین را می‌خواند</summary>
        private static string Format(object v)
        {
            if (v == null || v == DBNull.Value) return null;
            if (v is DateTime) return ((DateTime)v).ToString("yyyy-MM-dd HH:mm:ss");
            if (v is byte[]) return Convert.ToBase64String((byte[])v);
            if (v is bool) return ((bool)v) ? "1" : "0";
            return Convert.ToString(v, CultureInfo.InvariantCulture);
        }
    }
}
