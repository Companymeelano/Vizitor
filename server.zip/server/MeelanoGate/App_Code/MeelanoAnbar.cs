using System;

namespace Meelano.Gate
{
    /// <summary>
    /// دروازهٔ نقش **انباردار** — سرویس MeelanoGate.
    ///
    /// مسیر: /MeelanoAnbar.ashx
    ///
    /// این نقش فقط می‌تواند جدول‌های فهرست زیر را بخواند. محدودیت سمت
    /// سرور اجبار می‌شود، نه فقط در رابط کاربری پنهان شود — یعنی حتی با
    /// داشتن کلید دسترسی، کوئری روی جدول بیرون از این فهرست ۴۰۳ می‌گیرد.
    ///
    /// منبع فهرست: جداول واقعی سیستم Anbar که در
    /// `docs/unified-role-architecture.md` مستند شده است.
    /// </summary>
    public class MeelanoAnbar : MeelanoCore
    {
        public override string RoleId { get { return "warehouse"; } }

        public override string RoleFaName { get { return "انباردار"; } }

        public override string[] AllowedTables
        {
            get
            {
                return new string[]
                {
                    "anbars",
                    "anbarSanadType",
                    "AnbarSanad",
                    "subAnbarSanad",
                    "sanad_enteghal",
                    "kasr_e_sanad",
                    "b_az_mosh_sanad",
                    "back_sanad",
                    "backsail_temp",
                    "subBackSail_pish",
                    "inventory",
                    "inventory_anbars",
                    "Inventory_Anbars_PS",
                    "Inventory_coka",
                    "InvantoryAnbar",
                    "InvantoryAnbarPS",
                    "kagroup",
                    "ka_act",
                    "Production",
                    "ProductionSeries",
                    "ProductionSeriesID",
                    "custgroup",
                    "CUSTOMERS",
                    "deviceAnbar",
                    "osystems",
                    "taraz",
                    "TarazHistory",
                    "sailfact",
                    "sailfact_pish",
                    "subsailfact",
                    "subsailfact_pish",
                    "sys_anb",
                    "sys_cus",
                    "sys_kal",
                    "sys_use",
                    "sys_users",
                    "SubSystemPermission",
                    "UserAnbar",
                    "visitors",
                    "VW_AnbarList",
                    "VW_MojodiWarehousing",
                    "VWForushKhales",
                    "overal_setting",
                };
            }
        }
    }
}
