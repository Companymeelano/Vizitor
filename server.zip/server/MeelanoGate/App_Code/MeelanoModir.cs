using System;

namespace Meelano.Gate
{
    /// <summary>
    /// دروازهٔ نقش **مدیریت** — سرویس MeelanoGate.
    ///
    /// مسیر: /MeelanoModir.ashx
    ///
    /// تنها نقشی است که محدودیت جدول ندارد (`AllowedTables == null`)، چون
    /// مدیریت باید به همهٔ بخش‌ها دسترسی داشته باشد. سایر لایه‌های امنیتی
    /// — کلید اجباری، فقط-خواندنی، سقف سطر و زمان — برای این نقش هم
    /// برقرار است.
    ///
    /// چون این دروازه بی‌محدودیت است، کلید دسترسی آن باید جدا و قوی‌تر از
    /// بقیه باشد. installer برای هر نقش کلید جدا تولید می‌کند.
    /// </summary>
    public class MeelanoModir : MeelanoCore
    {
        public override string RoleId { get { return "manager"; } }

        public override string RoleFaName { get { return "مدیریت"; } }

        /// <summary>null = بدون محدودیت جدول</summary>
        public override string[] AllowedTables { get { return null; } }
    }
}
