<#
.SYNOPSIS
    نصب یک‌مرحله‌ای سرویس گزارش M●D Report روی IIS.

.DESCRIPTION
    هر کاری که برای اتصال اپ اندرویدی به SQL Server لازم است را یک‌جا انجام می‌دهد:
      ۱) فعال‌کردن ویژگی‌های IIS در صورت نبود
      ۲) کپی فایل‌ها به مسیر نصب (پیش‌فرض C:\MReport\service)
      ۳) نوشتن تنظیمات SQL و کلید دسترسی در Web.config
      ۴) ساخت Application Pool و سایت IIS روی پورت مشخص (پیش‌فرض 8731)
      ۵) بازکردن فایروال ویندوز برای همان پورت
      ۶) تست سلامت و چاپ نتیجه

    هیچ مرحلهٔ Build ندارد — ASP.NET فایل App_Code\ReportGateway.cs را در زمان
    اجرا کامپایل می‌کند.

.PARAMETER Port
    پورتی که اپ اندرویدی به آن وصل می‌شود. پیش‌فرض 8731.

.EXAMPLE
    .\install-MReportService.ps1

.EXAMPLE
    .\install-MReportService.ps1 -Port 8731 -SqlServer "." -SqlPort 1433 `
        -SqlDatabase "Atiran2" -SqlUser "sa" -SqlPassword "***" -ApiKey "یک-رشته-تصادفی"

.NOTES
    باید با دسترسی Administrator اجرا شود.
#>
[CmdletBinding()]
param(
    [string] $SiteName    = "MReportService",
    [string] $InstallDir  = "C:\MReport\service",
    [int]    $Port        = 8731,
    [string] $SqlServer   = ".",
    [string] $SqlPort     = "1433",
    [string] $SqlDatabase = "Atiran2",
    [string] $SqlUser     = "",
    [string] $SqlPassword = "",
    [string] $ApiKey      = ""
)

$ErrorActionPreference = "Stop"

# ---------------------------------------------------- ۰-الف) کلید دسترسی اجباری
# تا این کلید داده نشود سرویس نصب نمی‌شود. پورتِ متفاوت به‌تنهایی امنیت
# نمی‌آورد؛ تنها چیزی که دسترسی بی‌اجازه را می‌بندد همین کلید است.
if ([string]::IsNullOrWhiteSpace($ApiKey)) {
    Write-Host ""
    Write-Host "   نصب متوقف شد: پارامتر -ApiKey اجباری است." -ForegroundColor Red
    Write-Host ""
    Write-Host "   این سرویس کوئری SELECT روی دیتابیس را از راه HTTP اجرا می‌کند."
    Write-Host "   بدون کلید، هر کسی که به پورت $Port برسد به داده‌های شما دسترسی دارد."
    Write-Host ""
    Write-Host "   یک کلید تصادفی بلند بسازید و دوباره اجرا کنید:" -ForegroundColor Yellow
    $sug = -join ((48..57)+(97..122)+(65..90) | Get-Random -Count 32 | ForEach-Object {[char]$_})
    Write-Host "     .\install-MReportService.ps1 -ApiKey `"$sug`"" -ForegroundColor White
    Write-Host ""
    Write-Host "   همین کلید را در اپ اندرویدی، فیلد «کلید دسترسی سرویس» وارد کنید."
    exit 1
}
if ($ApiKey.Length -lt 16) {
    Write-Host ""
    Write-Host "   نصب متوقف شد: -ApiKey باید حداقل ۱۶ نویسه باشد (الان $($ApiKey.Length))." -ForegroundColor Red
    exit 1
}

function Write-Step($msg)  { Write-Host "`n== $msg" -ForegroundColor Cyan }
function Write-Ok($msg)    { Write-Host "   [OK] $msg" -ForegroundColor Green }
function Write-Warn($msg)  { Write-Host "   [!]  $msg" -ForegroundColor Yellow }
function Write-Bad($msg)   { Write-Host "   [X]  $msg" -ForegroundColor Red }

# ------------------------------------------------------------ ۰) دسترسی ادمین
$id = [Security.Principal.WindowsIdentity]::GetCurrent()
$isAdmin = (New-Object Security.Principal.WindowsPrincipal($id)).IsInRole(
    [Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Bad "این اسکریپت باید با دسترسی Administrator اجرا شود."
    exit 1
}

$sourceDir = Join-Path $PSScriptRoot "MReportService"
if (-not (Test-Path (Join-Path $sourceDir "Report.ashx"))) {
    Write-Bad "پوشهٔ MReportService کنار این اسکریپت پیدا نشد: $sourceDir"
    exit 1
}

Write-Host ""
Write-Host "  نصب سرویس گزارش M●D Report" -ForegroundColor White
Write-Host "  مسیر : $InstallDir"
Write-Host "  پورت : $Port"
Write-Host "  SQL  : $SqlServer$(if ($SqlPort) { ",$SqlPort" }) / $SqlDatabase"
Write-Host ""

# ------------------------------------------------------------ ۱) ویژگی‌های IIS
Write-Step "فعال‌کردن ویژگی‌های IIS (در صورت نبود)"
$features = @(
    "IIS-WebServerRole", "IIS-WebServer", "IIS-CommonHttpFeatures",
    "IIS-StaticContent", "IIS-DefaultDocument", "IIS-HttpErrors",
    "IIS-ApplicationDevelopment", "IIS-ASPNET45", "IIS-NetFxExtensibility45",
    "IIS-ISAPIFilter", "IIS-ISAPIExtensions", "IIS-ManagementScriptingTools"
)
try {
    $enabled = Get-WindowsOptionalFeature -Online |
        Where-Object { $features -contains $_.FeatureName -and $_.State -eq "Enabled" } |
        Select-Object -ExpandProperty FeatureName
    $missing = $features | Where-Object { $enabled -notcontains $_ }
    if ($missing) {
        Write-Host "   در حال فعال‌کردن: $($missing -join ', ')"
        Enable-WindowsOptionalFeature -Online -FeatureName $missing -All -NoRestart | Out-Null
        Write-Ok "ویژگی‌ها فعال شدند"
    } else {
        Write-Ok "همهٔ ویژگی‌های لازم فعال بودند"
    }
} catch {
    Write-Warn "بررسی ویژگی‌های ویندوز ناموفق بود: $($_.Exception.Message)"
    Write-Warn "اگر IIS نصب نیست، دستی فعالش کنید و دوباره اجرا کنید."
}

Import-Module WebAdministration -ErrorAction SilentlyContinue

# ------------------------------------------------------------ ۲) کپی فایل‌ها
Write-Step "کپی فایل‌ها به $InstallDir"
New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
Copy-Item -Path (Join-Path $sourceDir "*") -Destination $InstallDir -Recurse -Force
Write-Ok "کپی شد"

# ------------------------------------------------------------ ۳) تنظیمات
Write-Step "نوشتن تنظیمات در Web.config"
$cfgPath = Join-Path $InstallDir "Web.config"
[xml] $xml = Get-Content $cfgPath -Encoding UTF8

foreach ($n in $xml.configuration.appSettings.add) {
    switch ($n.key) {
        "SqlServer"   { $n.value = $SqlServer }
        "SqlPort"     { $n.value = $SqlPort }
        "SqlDatabase" { $n.value = $SqlDatabase }
        "SqlUser"     { $n.value = $SqlUser }
        "SqlPassword" { $n.value = $SqlPassword }
        "ApiKey"      { $n.value = $ApiKey }
    }
}
$xml.Save($cfgPath)
Write-Ok "تنظیمات نوشته شد"
if ([string]::IsNullOrWhiteSpace($SqlUser)) {
    Write-Warn "SqlUser خالی است → سرویس با Windows Authentication وصل می‌شود."
    Write-Warn "در این حالت هویت Application Pool باید در SQL Server دسترسی داشته باشد."
}
Write-Ok "کلید دسترسی تنظیم شد ($($ApiKey.Length) نویسه)"

# ------------------------------------------------------------ ۴) سایت IIS
Write-Step "ساخت Application Pool و سایت IIS"
if (Test-Path "IIS:\AppPools\$SiteName") {
    Write-Host "   Application Pool موجود است — متوقف و به‌روزرسانی می‌شود"
    Stop-WebAppPool -Name $SiteName -ErrorAction SilentlyContinue
} else {
    New-WebAppPool -Name $SiteName | Out-Null
    Write-Ok "Application Pool ساخته شد: $SiteName"
}
# تنظیمات پایداری: بدون خاموشی خودکار، تا اولین درخواست cold start نخورد
Set-ItemProperty "IIS:\AppPools\$SiteName" -Name processModel.idleTimeout   -Value ([TimeSpan]::Zero)
Set-ItemProperty "IIS:\AppPools\$SiteName" -Name recycling.periodicRestart.time -Value ([TimeSpan]::Zero)
Set-ItemProperty "IIS:\AppPools\$SiteName" -Name managedRuntimeVersion     -Value "v4.0"
Set-ItemProperty "IIS:\AppPools\$SiteName" -Name managedPipelineMode       -Value "Integrated"
Write-Ok "Idle Time-out و بازیافت دوره‌ای خاموش شد (برای سرعت)"

if (Test-Path "IIS:\Sites\$SiteName") {
    Write-Host "   سایت موجود است — binding به‌روزرسانی می‌شود"
    Remove-Website -Name $SiteName
}
New-Website -Name $SiteName -Port $Port -PhysicalPath $InstallDir `
            -ApplicationPool $SiteName -Force | Out-Null
Write-Ok "سایت ساخته شد: http://localhost:$Port"

Start-WebAppPool -Name $SiteName -ErrorAction SilentlyContinue
Start-Website     -Name $SiteName -ErrorAction SilentlyContinue

# ------------------------------------------------------------ ۵) فایروال
Write-Step "بازکردن فایروال ویندوز برای پورت $Port"
$ruleName = "M●D Report Service (TCP $Port)"
if (Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue) {
    Set-NetFirewallRule -DisplayName $ruleName -Enabled True -Action Allow
    Write-Ok "قانون فایروال موجود بود و فعال شد"
} else {
    New-NetFirewallRule -DisplayName $ruleName -Direction Inbound -Action Allow `
        -Protocol TCP -LocalPort $Port -Profile Any | Out-Null
    Write-Ok "قانون فایروال ساخته شد"
}

# ------------------------------------------------------------ ۶) تست
Write-Step "تست سلامت سرویس"
$url = "http://localhost:$Port/Report.ashx"
$ok = $false
for ($i = 1; $i -le 4 -and -not $ok; $i++) {
    try {
        $r = Invoke-WebRequest -Uri $url -TimeoutSec 20 -UseBasicParsing
        Write-Host "   پاسخ: $($r.Content)" -ForegroundColor DarkGray
        if ($r.Content -match '"ok"\s*:\s*true') { $ok = $true } else {
            Write-Warn "سرویس بالا آمد ولی اتصال SQL برقرار نشد — تنظیمات SQL را بررسی کنید."
            $ok = $true   # خود سرویس سالم است؛ مشکل از SQL است
        }
    } catch {
        Write-Warn "تلاش $i ناموفق: $($_.Exception.Message)"
        Start-Sleep -Seconds 3
    }
}

$lan = (Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
        Where-Object { $_.IPAddress -notlike "127.*" -and $_.IPAddress -notlike "169.254.*" } |
        Select-Object -First 1 -ExpandProperty IPAddress)

Write-Host ""
Write-Host "======================================================" -ForegroundColor Green
if ($ok) {
    Write-Host "  نصب کامل شد." -ForegroundColor Green
    Write-Host ""
    Write-Host "  در اپ اندرویدی، خانهٔ «آدرس سرویس M●D Report» را پر کنید:"
    if ($lan) { Write-Host "     داخل شبکه : http://$lan`:$Port" -ForegroundColor White }
    Write-Host "     از بیرون  : http://<IP-عمومی>`:$Port   (نیاز به Port Forward در روتر)"
    Write-Host ""
    Write-Host "  تست در مرورگر: $url" -ForegroundColor DarkGray
} else {
    Write-Host "  سرویس بالا نیامد. این‌ها را چک کنید:" -ForegroundColor Red
    Write-Host "    iisreset"
    Write-Host "    Event Viewer → Windows Logs → Application"
    Write-Host "    آیا پورت $Port توسط برنامهٔ دیگری اشغال نشده؟  netstat -ano | findstr $Port"
}
Write-Host "======================================================" -ForegroundColor Green
Write-Host ""
