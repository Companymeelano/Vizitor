# خروجی موردانتظار تست سلامت MeelanoGate

این سند «شکلِ دقیق» پاسخی را نشان می‌دهد که سرویس سالم برمی‌گرداند تا بدانید
«وصل شد» چه شکلی است. مقادیر `server` / `version` / `utc` از SQL Server خودِ شما
می‌آید و با ماشین شما فرق می‌کند؛ **ساختار و فیلدها ثابت‌اند**.

اسکریپت `test-MeelanoGate.ps1` دقیقاً همین ساختار را چاپ و اعتبارسنجی می‌کند.

## یک نمونهٔ کامل (نقش مدیریت)

درخواست:
```
GET http://192.168.1.110:8731/MeelanoModir.ashx
X-Meelano-Key: <کلید-شما>
```

پاسخ سالم (HTTP 200):
```json
{
  "ok": true,
  "service": "MeelanoGate",
  "role": "manager",
  "roleFa": "مدیریت",
  "server": "MIGHTY",
  "version": "Microsoft SQL Server 2019 (RTM-CU...) ...",
  "database": "Atiran2",
  "utc": "2026-09-13T12:34:56.7890123Z",
  "error": null
}
```

## جدول چهار endpoint

| فایل | role | roleFa | وضعیت سالم |
|---|---|---|---|
| `MeelanoModir.ashx` | manager | مدیریت | 200 + ok=true |
| `MeelanoAnbar.ashx` | warehouse | انباردار | 200 + ok=true |
| `MeelanoVizit.ashx` | visitor | ویزیتور | 200 + ok=true |
| `MeelanoPakhsh.ashx` | distributor | مامور پخش | 200 + ok=true |

## خروجی کنسولی موردانتظار اسکریپت

```
تست سلامت MeelanoGate — پایه: http://192.168.1.110:8731
--------------------------------------------------------------
[OK]   مدیریت  ←  http://192.168.1.110:8731/MeelanoModir.ashx
       ok=True  service=MeelanoGate  role=manager  roleFa=مدیریت
       server=MIGHTY  database=Atiran2
       version=Microsoft SQL Server 2019 ...
--------------------------------------------------------------
[OK]   انباردار  ←  http://192.168.1.110:8731/MeelanoAnbar.ashx
       ok=True  service=MeelanoGate  role=warehouse  roleFa=انباردار
       server=MIGHTY  database=Atiran2
       ...
--------------------------------------------------------------
[OK]   ویزیتور  ←  http://192.168.1.110:8731/MeelanoVizit.ashx
       ...
--------------------------------------------------------------
[OK]   مامور پخش  ←  http://192.168.1.110:8731/MeelanoPakhsh.ashx
       ...
--------------------------------------------------------------
[OK]   بدون کلید → 401 (لایهٔ دسترسی فعال است)

نتیجه: هر ۴ endpoint سالم‌اند. آدرس اپ: http://192.168.1.110:8731
```

## نشانه‌های خرابی و معنایشان

| علامت | معنا | اقدام |
|---|---|---|
| `[FAIL] ... Unable to connect` | پورت/فایروال/سایت پایین | پورت 8731 و App Pool را چک کنید |
| `ok=false` با خطای SQL | اتصال SQL برقرار نیست | رشتهٔ اتصال `Web.config` را چک کنید |
| بدون کلید → 200 | لایهٔ دسترسی خاموش | `ApiKey` در `Web.config` خالی است؛ پر کنید |
| 401 با کلید درست | کلید اپ با سرور یکسان نیست | کلید را عیناً در اپ و سرور یکسان کنید |
