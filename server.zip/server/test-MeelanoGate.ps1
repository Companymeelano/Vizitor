<#
.SYNOPSIS
    تست سلامت چهار endpoint سرویس MeelanoGate — بدون نصب، فقط بررسی اتصال.
.DESCRIPTION
    به هر چهار .ashx یک درخواست GET (ping) می‌فرستد و پاسخ JSON واقعی را چاپ
    می‌کند؛ سپس یک درخواست «بدون کلید» می‌فرستد که باید 401 برگرداند (بررسی
    اینکه لایهٔ دسترسی روشن است).

    خروجی موردانتظار برای هر endpoint یک JSON با ok=true و role همان نقش است.
.EXAMPLE
    .\test-MeelanoGate.ps1 -BaseUrl "http://192.168.1.110:8731" -ApiKey "Meelano-1404-a1b2c3d4e5"
.EXAMPLE
    .\test-MeelanoGate.ps1 -BaseUrl "http://37.143.148.14:8731" -ApiKey "کلید-خودتان"
.NOTES
    روی همان سرور یا هر ماشینی که به پورت دسترسی دارد اجرا شود. PowerShell 5 کافی است.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string] $BaseUrl,
    [Parameter(Mandatory=$true)][string] $ApiKey
)

$ErrorActionPreference = "Stop"
$BaseUrl = $BaseUrl.TrimEnd("/")

$roles = @(
    @{ file="MeelanoModir.ashx";  id="manager";     fa="مدیریت"   },
    @{ file="MeelanoAnbar.ashx";  id="warehouse";   fa="انباردار" },
    @{ file="MeelanoVizit.ashx";  id="visitor";     fa="ویزیتور"  },
    @{ file="MeelanoPakhsh.ashx"; id="distributor"; fa="مامور پخش" }
)

function Line($c) { Write-Host ("-" * 62) -ForegroundColor DarkGray }

Write-Host ""
Write-Host "تست سلامت MeelanoGate — پایه: $BaseUrl" -ForegroundColor Cyan
Line

$pass = 0
foreach ($r in $roles) {
    $u = "$BaseUrl/$($r.file)"
    try {
        $resp = Invoke-WebRequest -Uri $u -Headers @{ "X-Meelano-Key" = $ApiKey } `
                  -UseBasicParsing -TimeoutSec 20
        $json = $resp.Content | ConvertFrom-Json
        if ($resp.StatusCode -eq 200 -and $json.ok -eq $true -and $json.role -eq $r.id) {
            Write-Host "[OK]   $($r.fa)  ←  $u" -ForegroundColor Green
            Write-Host "       ok=$($json.ok)  service=$($json.service)  role=$($json.role)  roleFa=$($json.roleFa)"
            Write-Host "       server=$($json.server)  database=$($json.database)"
            Write-Host "       version=$($json.version)"
            $pass++
        } else {
            Write-Host "[BAD]  $($r.fa)  ←  پاسخ نامعتبر: status=$($resp.StatusCode) ok=$($json.ok) role=$($json.role)" -ForegroundColor Yellow
        }
    } catch {
        Write-Host "[FAIL] $($r.fa)  ←  $u" -ForegroundColor Red
        Write-Host "       $($_.Exception.Message)" -ForegroundColor Red
    }
    Line
}

# بررسی لایهٔ دسترسی: بدون کلید باید 401 بگیریم
$u = "$BaseUrl/MeelanoModir.ashx"
try {
    $resp = Invoke-WebRequest -Uri $u -UseBasicParsing -TimeoutSec 20
    Write-Host "[WARN] بدون کلید هم پاسخ 200 گرفتیم! لایهٔ دسترسی روشن نیست." -ForegroundColor Yellow
} catch {
    $code = $_.Exception.Response.StatusCode.value__
    if ($code -eq 401) {
        Write-Host "[OK]   بدون کلید → 401 (لایهٔ دسترسی فعال است)" -ForegroundColor Green
    } else {
        Write-Host "[WARN] بدون کلید → کد $code (انتظار 401)" -ForegroundColor Yellow
    }
}

Write-Host ""
if ($pass -eq $roles.Count) {
    Write-Host "نتیجه: هر ۴ endpoint سالم‌اند. آدرس اپ: $BaseUrl" -ForegroundColor Green
} else {
    Write-Host "نتیجه: $pass از $($roles.Count) endpoint سالم است." -ForegroundColor Yellow
    Write-Host "اگر هیچ‌کدام پاسخ نداد: فایروال/پورت و App Pool را بررسی کنید." -ForegroundColor Yellow
}
Write-Host ""
