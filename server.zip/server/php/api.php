<?php
/**
 * ============================================================================
 *  Atiran Visitor API — واسط PHP 8.3 بین اپ ویزیتور و SQL Server آتیران
 *  Developed by Milano Technical Team, Milad Yaghoobi
 * ============================================================================
 *  Endpoint ها:
 *    GET  api.php?action=customers   → لیست مشتریان
 *    GET  api.php?action=products    → لیست کالاها + موجودی
 *    POST api.php?action=order       → ثبت فاکتور (SalesHeader + SalesLines) با تراکنش
 *
 *  خروجی همیشه JSON استاندارد است:
 *    موفق:  {"ok":true,  "data": ...}
 *    خطا:   {"ok":false, "error":{"code":..., "message":...}}
 */

declare(strict_types=1);

// --------------------------------------------------------------- پیکربندی
// مقادیر را از متغیر محیطی بخوان تا هیچ رمزِ سخت‌کدشده‌ای در سورس نماند.
const DB_HOST = 'MSSQL_HOST';   // getenv
const DB_PORT = '1433';
const DB_NAME = 'Atiran2';

function cfg(): array
{
    return [
        'host' => getenv('MSSQL_HOST') ?: '127.0.0.1',
        'port' => getenv('MSSQL_PORT') ?: DB_PORT,
        'db'   => getenv('MSSQL_DB')   ?: DB_NAME,
        'user' => getenv('MSSQL_USER') ?: '',
        'pass' => getenv('MSSQL_PASS') ?: '',
    ];
}

// کلید دسترسی ساده برای اپ (از هدر X-Api-Key) — خالی یعنی بدون کلید
const API_KEY = 'MSSQL_APIKEY';

// --------------------------------------------------------------- ابزار JSON
function out(array $payload, int $http = 200): never
{
    http_response_code($http);
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Headers: Content-Type, X-Api-Key');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function fail(string $code, string $message, int $http = 400): never
{
    out(['ok' => false, 'error' => ['code' => $code, 'message' => $message]], $http);
}

// --------------------------------------------------------------- اتصال PDO
function connect(): PDO
{
    $c = cfg();
    $dsn = "sqlsrv:Server={$c['host']},{$c['port']};Database={$c['db']};TrustServerCertificate=yes";
    try {
        $pdo = new PDO($dsn, $c['user'], $c['pass'], [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
        return $pdo;
    } catch (PDOException $e) {
        fail('DB_CONNECT', 'اتصال به SQL Server برقرار نشد: ' . $e->getMessage(), 500);
    }
}

// --------------------------------------------------------------- احراز هویت
function checkKey(): void
{
    $want = getenv(API_KEY) ?: '';
    if ($want === '') return; // کلید تنظیم نشده → باز
    $got = $_SERVER['HTTP_X_API_KEY'] ?? '';
    if (!hash_equals($want, (string)$got)) {
        fail('AUTH', 'کلید دسترسی نامعتبر است', 401);
    }
}

// --------------------------------------------------------------- خواندن
function listCustomers(PDO $pdo): array
{
    $st = $pdo->query('SELECT SHMO AS id, Name AS name, Phone AS phone, Address AS address
                       FROM CUSTOMER ORDER BY Name');
    return $st->fetchAll();
}

function listProducts(PDO $pdo): array
{
    $st = $pdo->query('SELECT KalID AS id, KalName AS name, Price AS price, Stock AS stock
                       FROM inventory ORDER BY KalName');
    return $st->fetchAll();
}

// --------------------------------------------------------------- ثبت فاکتور
function saveOrder(PDO $pdo, array $body): array
{
    $customerId = (int)($body['customerId'] ?? 0);
    $lines      = $body['lines'] ?? [];
    if ($customerId <= 0)            fail('VALIDATION', 'مشتری نامعتبر است');
    if (!is_array($lines) || !$lines) fail('VALIDATION', 'هیچ قلمی ارسال نشده است');

    $pdo->beginTransaction();
    try {
        $h = $pdo->prepare('INSERT INTO SalesHeader (CustomerID, FactDate, Total, Visitor)
                            OUTPUT INSERTED.FactID
                            VALUES (?, GETDATE(), ?, ?)');
        $total = 0.0;
        foreach ($lines as $l) {
            $total += ((float)($l['qty'] ?? 0)) * ((float)($l['price'] ?? 0));
        }
        $h->execute([$customerId, $total, (string)($body['visitor'] ?? '')]);
        $factId = (int)$h->fetchColumn();

        $d = $pdo->prepare('INSERT INTO SalesLines (FactID, KalID, Qty, Price, Amount)
                            VALUES (?, ?, ?, ?, ?)');
        foreach ($lines as $l) {
            $qty   = (float)($l['qty'] ?? 0);
            $price = (float)($l['price'] ?? 0);
            $d->execute([$factId, (int)($l['productId'] ?? 0), $qty, $price, $qty * $price]);
        }

        $pdo->commit();
        return ['factId' => $factId, 'total' => $total];
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        fail('DB_WRITE', 'ثبت فاکتور ناموفق: ' . $e->getMessage(), 500);
    }
}

// --------------------------------------------------------------- مسیریابی
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') out(['ok' => true]);
checkKey();

$action = $_GET['action'] ?? '';
$pdo    = connect();

if ($action === 'customers' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    out(['ok' => true, 'data' => listCustomers($pdo)]);
}
if ($action === 'products' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    out(['ok' => true, 'data' => listProducts($pdo)]);
}
if ($action === 'order' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $body = json_decode(file_get_contents('php://input') ?: '[]', true) ?: [];
    out(['ok' => true, 'data' => saveOrder($pdo, $body)]);
}

fail('ROUTE', 'اکشن نامعتبر است', 404);

// Developed by Milano Technical Team, Milad Yaghoobi
