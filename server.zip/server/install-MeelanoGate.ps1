<#
.SYNOPSIS
    نصب یک‌جا سرویس MeelanoGate روی IIS.

.DESCRIPTION
    دروازهٔ نقش‌محور گزارش اتیران — طراحی Meelano Studio Design،
    برنامه‌نویس میلاد یعقوبی.

    هر نقش یک endpoint جدا دارد و محدودیت جدولش سمت سرور اجبار می‌شود:

        MeelanoModir.ashx    مدیریت     — بدون محدودیت جدول
        MeelanoAnbar.ashx    انباردار   — ۴۳ جدول انبار
        MeelanoVizit.ashx    ویزیتور    — ۵۳ جدول ویزیت
        MeelanoPakhsh.ashx   مامور پخش  — ۳۷ جدول پخش

    چه کارهایی انجام می‌دهد:
      ۱) فعال‌کردن ویژگی‌های لازم IIS
      ۲) کپی سرویس به مسیر نصب
      ۳) نوشتن تنظیمات در Web.config
      ۴) ساخت Application Pool و سایت روی پورت مشخص
      ۵) قاعدهٔ فایروال
      ۶) تست سلامت هر چهار endpoint و چاپ آدرس‌ها

.PARAMETER ApiKey
    کلید دسترسی — **اجباری**. سرویس بدون کلید بالا نمی‌آید و installer
    هم بدون آن نصب نمی‌کند.

.EXAMPLE
    .\install-MeelanoGate.ps1 -ApiKey "یک-رشته-تصادفی-بلند"

.NOTES
    باید با دسترسی Administrator اجرا شود.
#>
[CmdletBinding()]
param(
    [string] $SiteName    = "MeelanoGate",
    [string] $InstallDir  = "C:\Meelano\gate",
    [int]    $Port        = 8731,
    [string] $SqlServer   = ".",
    [string] $SqlPort     = "1433",
    [string] $SqlDatabase = "Atiran2",
    [string] $SqlUser     = "",
    [string] $SqlPassword = "",
    [string] $ApiKey      = "",
    # اگر در استقرار واقعی جدولی از فهرست مجاز جا افتاد، false کنید
    [string] $EnforceTableScope = "true"
)

$ErrorActionPreference = "Stop"

function Write-Step($msg) { Write-Host "`n== $msg" -ForegroundColor Cyan }
function Write-Ok($msg)   { Write-Host "   [OK] $msg" -ForegroundColor Green }
function Write-Warn($msg) { Write-Host "   [!]  $msg" -ForegroundColor Yellow }
function Write-Bad($msg)  { Write-Host "   [X]  $msg" -ForegroundColor Red }

# ------------------------------------------------------ ۰-الف) کلید اجباری
# تا کلید داده نشود نصب انجام نمی‌شود. سرویس کوئری SELECT را از راه HTTP
# اجرا می‌کند؛ بدون کلید هر کسی که به پورت برسد به داده دسترسی دارد.
if ([string]::IsNullOrWhiteSpace($ApiKey)) {
    Write-Host ""
    Write-Host "   نصب متوقف شد: پارامتر -ApiKey اجباری است." -ForegroundColor Red
    Write-Host ""
    Write-Host "   یک کلید تصادفی بلند بسازید و دوباره اجرا کنید:" -ForegroundColor Yellow
    $sug = -join ((48..57)+(97..122)+(65..90) | Get-Random -Count 32 | ForEach-Object {[char]$_})
    Write-Host "     .\install-MeelanoGate.ps1 -ApiKey `"$sug`"" -ForegroundColor White
    Write-Host ""
    Write-Host "   همین کلید را در اپ اندرویدی، فیلد «کلید دسترسی سرویس» وارد کنید."
    exit 1
}
if ($ApiKey.Length -lt 16) {
    Write-Host ""
    Write-Host "   نصب متوقف شد: -ApiKey باید حداقل ۱۶ نویسه باشد (الان $($ApiKey.Length))." -ForegroundColor Red
    exit 1
}

# ---------------------------------------------------- ۰-ب) دسترسی ادمین
$id = [Security.Principal.WindowsIdentity]::GetCurrent()
$isAdmin = (New-Object Security.Principal.WindowsPrincipal($id)).IsInRole(
    [Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Bad "این اسکریپت باید با دسترسی Administrator اجرا شود."
    exit 1
}

# ---------------------------------------------------- ۰-ج) اعتبار منبع
$src = Join-Path $PSScriptRoot "MeelanoGate"
if (-not (Test-Path (Join-Path $src "MeelanoModir.ashx"))) {
    Write-Bad "پوشهٔ سرویس کنار این اسکریپت پیدا نشد: $src"
    Write-Bad "انتظار می‌رفت MeelanoModir.ashx داخلش باشد."
    exit 1
}

# ---------------------------------------------------- ۱) ویژگی‌های IIS
Write-Step "فعال‌کردن ویژگی‌های IIS"
$features = @("IIS-WebServerRole","IIS-WebServer","IIS-CommonHttpFeatures",
              "IIS-StaticContent","IIS-DefaultDocument","IIS-HttpErrors",
              "IIS-ApplicationDevelopment","IIS-ISAPIExtensions",
              "IIS-NetFxExtensibility45","IIS-ASPNET45","IIS-ISAPIFilter",
              "IIS-RequestFiltering","IIS-HttpLogging","IIS-RequestMonitor",
              "NetFx4Extended-ASPNET45")
foreach ($f in $features) {
    $st = (Get-WindowsOptionalFeature -Online -FeatureName $f -ErrorAction SilentlyContinue)
    if ($st -and $st.State -ne "Enabled") {
        Enable-WindowsOptionalFeature -Online -FeatureName $f -All -NoRestart | Out-Null
        Write-Ok "فعال شد: $f"
    }
}
Import-Module WebAdministration -ErrorAction SilentlyContinue
if (-not (Get-Module WebAdministration)) { Import-Module IISAdministration }

# ---------------------------------------------------- ۲) کپی سرویس
Write-Step "کپی سرویس به $InstallDir"
if (-not (Test-Path $InstallDir)) { New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null }
Copy-Item -Path (Join-Path $src "*") -Destination $InstallDir -Recurse -Force
Write-Ok "کپی انجام شد"

# ---------------------------------------------------- ۳) تنظیمات
Write-Step "نوشتن تنظیمات در Web.config"
$cfgPath = Join-Path $InstallDir "Web.config"
[xml]$xml = Get-Content $cfgPath -Encoding UTF8
foreach ($n in $xml.configuration.appSettings.add) {
    switch ($n.key) {
        "SqlServer"          { $n.value = $SqlServer }
        "SqlPort"            { $n.value = $SqlPort }
        "SqlDatabase"        { $n.value = $SqlDatabase }
        "SqlUser"            { $n.value = $SqlUser }
        "SqlPassword"        { $n.value = $SqlPassword }
        "ApiKey"             { $n.value = $ApiKey }
        "EnforceTableScope"  { $n.value = $EnforceTableScope }
    }
}
$xml.Save($cfgPath)
Write-Ok "تنظیمات نوشته شد"
Write-Ok "کلید دسترسی تنظیم شد ($($ApiKey.Length) نویسه)"
if ([string]::IsNullOrWhiteSpace($SqlUser)) {
    Write-Warn "SqlUser خالی است → سرویس با Windows Authentication وصل می‌شود."
    Write-Warn "هویت Application Pool باید در SQL Server دسترسی داشته باشد."
}
if ($EnforceTableScope -eq "false") {
    Write-Warn "EnforceTableScope=false → محدودیت جدول نقش‌ها غیرفعال است."
    Write-Warn "هر نقش می‌تواند هر جدولی را بخواند. فقط موقتاً استفاده کنید."
}

# ---------------------------------------------------- ۴) سایت IIS
Write-Step "ساخت Application Pool و سایت IIS"
if (Test-Path "IIS:\AppPools\$SiteName") {
    Stop-WebAppPool -Name $SiteName -ErrorAction SilentlyContinue
} else {
    New-WebAppPool -Name $SiteName | Out-Null
    Write-Ok "Application Pool ساخته شد: $SiteName"
}
# خاموش‌کردن بازیافت تا گزارش‌های سنگین وسط کار قطع نشوند
Set-ItemProperty "IIS:\AppPools\$SiteName" -Name processModel.idleTimeout -Value ([TimeSpan]::Zero)
Set-ItemProperty "IIS:\AppPools\$SiteName" -Name recycling.periodicRestart.time -Value ([TimeSpan]::Zero)

if (Test-Path "IIS:\Sites\$SiteName") {
    Remove-Website -Name $SiteName
}
New-Website -Name $SiteName -Port $Port -PhysicalPath $InstallDir `
            -ApplicationPool $SiteName -Force | Out-Null
Start-WebAppPool -Name $SiteName
Write-Ok "سایت بالا آمد روی پورت $Port"

# ---------------------------------------------------- ۵) فایروال
Write-Step "قاعدهٔ فایروال"
$rule = "MeelanoGate $Port"
if (Get-NetFirewallRule -DisplayName $rule -ErrorAction SilentlyContinue) {
    Remove-NetFirewallRule -DisplayName $rule
}
New-NetFirewallRule -DisplayName $rule -Direction Inbound -Action Allow `
    -Protocol TCP -LocalPort $Port -Profile Any | Out-Null
Write-Ok "پورت $Port باز شد"
Write-Warn "اگر این سرویس از اینترنت در دسترس است، بهتر است قاعده را به"
Write-Warn "IP دفتر محدود کنید — کلید دسترسی تنها لایهٔ محافظ باقی نماند."

# ---------------------------------------------------- ۶) تست سلامت
Write-Step "تست سلامت endpoint ها"
$roles = @(
    @{ n="MeelanoModir";  fa="مدیریت" },
    @{ n="MeelanoAnbar";  fa="انباردار" },
    @{ n="MeelanoVizit";  fa="ویزیتور" },
    @{ n="MeelanoPakhsh"; fa="مامور پخش" }
)
$anyOk = $false
foreach ($r in $roles) {
    $u = "http://localhost:$Port/$($r.n).ashx"
    $ok = $false
    for ($i=0; $i -lt 5 -and -not $ok; $i++) {
        try {
            $resp = Invoke-WebRequest -Uri $u -Headers @{ "X-Meelano-Key" = $ApiKey } `
                    -UseBasicParsing -TimeoutSec 20
            if ($resp.StatusCode -eq 200) { $ok = $true }
        } catch { Start-Sleep -Seconds 3 }
    }
    if ($ok) { Write-Ok "$($r.fa) → $u"; $anyOk = $true }
    else     { Write-Bad "$($r.fa) → پاسخ نگرفت: $u" }
}

# ---------------------------------------------------- خلاصه
$ip = (Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
       Where-Object { $_.IPAddress -notlike "127.*" -and $_.IPAddress -notlike "169.254.*" } |
       Select-Object -First 1).IPAddress

Write-Host ""
Write-Host "==================================================" -ForegroundColor Cyan
if ($anyOk) {
    Write-Host " سرویس MeelanoGate نصب شد." -ForegroundColor Green
} else {
    Write-Host " سرویس نصب شد ولی هیچ endpoint پاسخ نداد." -ForegroundColor Yellow
    Write-Host " لاگ IIS را ببینید: Event Viewer → Windows Logs → Application" -ForegroundColor Yellow
}
Write-Host ""
Write-Host " آدرسی که در اپ وارد می‌کنید:" -ForegroundColor White
Write-Host "   http://${ip}:$Port" -ForegroundColor White
Write-Host ""
Write-Host " کلید دسترسی را هم در فیلد «کلید دسترسی سرویس» اپ بگذارید." -ForegroundColor White
Write-Host ""
Write-Host " هر نقش خودکار به endpoint خودش وصل می‌شود:" -ForegroundColor DarkGray
foreach ($r in $roles) {
    Write-Host "   $($r.fa)  →  /$($r.n).ashx" -ForegroundColor DarkGray
}
Write-Host "==================================================" -ForegroundColor Cyan
