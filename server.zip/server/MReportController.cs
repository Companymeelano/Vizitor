using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Web.Http;
using Newtonsoft.Json;

namespace AtiranKingService.Controllers
{
    /// <summary>
    /// دروازهٔ کوئری **فقط-خواندنی** برای اپ اندرویدی M●D Report.
    ///
    /// چرا لازم است: پورت ۱۴۳۳ (پروتکل TDS) در این استقرار بسته/شنود می‌شود —
    /// دست‌دادن TCP انجام می‌شود ولی سرور بی‌پاسخ اتصال را می‌بندد. HTTP روی
    /// پورت IIS عبور می‌کند، پس اپ کوئری را این‌جا می‌فرستد و کوئری **محلی روی
    /// همان سرور** اجرا می‌شود.
    ///
    /// مسیرها (قالب مسیر خود سرویس: api/{controller}/{action}):
    ///   POST  api/MReport/Query   — اجرای یک SELECT
    ///   GET   api/MReport/Ping    — سلامت سرویس + نسخهٔ SQL
    ///
    /// امنیت:
    ///   ۱) فقط SELECT/WITH؛ هر کلیدواژهٔ نوشتاری رد می‌شود.
    ///   ۲) چند دستور در یک درخواست ممنوع (`;`).
    ///   ۳) پارامترها همیشه SqlParameter اند — الحاق رشته‌ای وجود ندارد.
    ///   ۴) نام دیتابیس فقط [A-Za-z0-9_] پذیرفته می‌شود (جلوگیری از تزریق به
    ///      رشتهٔ اتصال).
    ///   ۵) سقف سخت روی تعداد سطر و زمان اجرا.
    ///   ۶) کلید مشترک اختیاری از راه هدر X-MReport-Key.
    ///
    /// نصب: این فایل را در پوشهٔ Controllers پروژهٔ AtiranKingService بگذارید،
    /// پروژه را Build و Publish کنید. وابستگی جدیدی ندارد — System.Data.SqlClient
    /// و Newtonsoft.Json هر دو از قبل در bin هستند.
    /// </summary>
    public class MReportController : ApiController
    {
        // سقف‌های سخت — حتی اگر کلاینت بیشتر بخواهد
        private const int HARD_MAX_ROWS = 5000;
        private const int HARD_TIMEOUT_SEC = 120;
        private const int DEFAULT_MAX_ROWS = 1000;
        private const int DEFAULT_TIMEOUT_SEC = 45;

        /// <summary>همان فهرست کلیدواژه‌های ممنوعِ سمت اپ — دو طرف یکی‌اند</summary>
        private static readonly string[] Forbidden =
        {
            "INSERT", "UPDATE", "DELETE", "DROP", "ALTER", "TRUNCATE", "MERGE",
            "EXEC", "EXECUTE", "CREATE", "GRANT", "REVOKE", "DENY",
            "BACKUP", "RESTORE", "SHUTDOWN", "KILL",
            "OPENROWSET", "OPENDATASOURCE",
        };

        // ------------------------------------------------------------ قرارداد

        public class QueryRequest
        {
            [JsonProperty("sql")] public string Sql { get; set; }
            [JsonProperty("database")] public string Database { get; set; }
            // List<object> و نه List<string>: Json.NET نوع واقعی JSON را حفظ کند.
            // با List<string> مقدار OFFSET/FETCH به رشته تبدیل می‌شد و SQL Server
            // خطای «must be an integer» می‌داد — صفحه‌بندی جدول‌ها می‌شکست.
            [JsonProperty("params")] public List<object> Parameters { get; set; }
            [JsonProperty("maxRows")] public int? MaxRows { get; set; }
            [JsonProperty("timeoutSec")] public int? TimeoutSec { get; set; }
        }

        // ------------------------------------------------------------ Ping

        /// <summary>GET api/MReport/Ping — سلامت سرویس و نسخهٔ SQL Server</summary>
        [HttpGet]
        public IHttpActionResult Ping()
        {
            var denied = CheckKey();
            if (denied != null) return denied;
            try
            {
                using (var cn = new SqlConnection(BuildConnectionString(null)))
                {
                    cn.Open();
                    using (var cmd = cn.CreateCommand())
                    {
                        cmd.CommandText = "SELECT @@SERVERNAME, @@VERSION, DB_NAME()";
                        cmd.CommandTimeout = 15;
                        using (var r = cmd.ExecuteReader())
                        {
                            if (!r.Read()) return Ok(Fail("پاسخی از SQL Server نرسید"));
                            return Ok(new
                            {
                                ok = true,
                                server = Safe(r, 0),
                                version = FirstLine(Safe(r, 1)),
                                database = Safe(r, 2),
                                utc = DateTime.UtcNow.ToString("o"),
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return Ok(Fail("اتصال به SQL Server ناموفق: " + ex.Message));
            }
        }

        // ------------------------------------------------------------ Query

        /// <summary>POST api/MReport/Query — اجرای یک کوئری فقط-خواندنی</summary>
        [HttpPost]
        public IHttpActionResult Query([FromBody] QueryRequest req)
        {
            var denied = CheckKey();
            if (denied != null) return denied;

            if (req == null) return Ok(Fail("بدنهٔ درخواست خالی است"));

            string problem;
            var sql = ValidateReadOnly(req.Sql, out problem);
            if (sql == null) return Ok(Fail(problem));

            var maxRows = Clamp(req.MaxRows ?? DEFAULT_MAX_ROWS, 1, HARD_MAX_ROWS);
            var timeout = Clamp(req.TimeoutSec ?? DEFAULT_TIMEOUT_SEC, 1, HARD_TIMEOUT_SEC);

            var sw = Stopwatch.StartNew();
            var columns = new List<string>();
            var rows = new List<List<string>>();
            var truncated = false;

            try
            {
                using (var cn = new SqlConnection(BuildConnectionString(req.Database)))
                {
                    cn.Open();
                    using (var cmd = cn.CreateCommand())
                    {
                        cmd.CommandText = sql;
                        cmd.CommandTimeout = timeout;
                        cmd.CommandType = CommandType.Text;

                        // لایهٔ دفاعی: اپ `?` را خودش به `@pN` تبدیل می‌کند، ولی اگر
                        // کلاینت دیگری `?` بفرستد این‌جا اصلاح می‌شود — وگرنه SQL Server
                        // خطای syntax می‌دهد چون `?` را قبول نمی‌کند.
                        cmd.CommandText = BindPlaceholders(cmd.CommandText);

                        if (req.Parameters != null)
                        {
                            for (var i = 0; i < req.Parameters.Count; i++)
                                AddParam(cmd, "@p" + i, req.Parameters[i]);
                        }

                        using (var r = cmd.ExecuteReader())
                        {
                            var n = r.FieldCount;
                            for (var i = 0; i < n; i++) columns.Add(r.GetName(i));

                            while (r.Read())
                            {
                                if (rows.Count >= maxRows) { truncated = true; break; }
                                var row = new List<string>(n);
                                for (var i = 0; i < n; i++)
                                {
                                    row.Add(r.IsDBNull(i) ? null : Format(r.GetValue(i)));
                                }
                                rows.Add(row);
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                return Ok(Fail("خطای SQL Server (" + ex.Number + "): " + ex.Message));
            }
            catch (Exception ex)
            {
                return Ok(Fail(ex.Message));
            }

            sw.Stop();
            return Ok(new
            {
                ok = true,
                columns = columns,
                rows = rows,
                truncated = truncated,
                rowCount = rows.Count,
                elapsedMs = sw.ElapsedMilliseconds,
                error = (string)null,
            });
        }

        // ------------------------------------------------------------ فقط-خواندنی

        /// <summary>
        /// دقیقاً همان قواعد سمت اپ (SqlServerDb.validateReadOnly). کوئری سالم
        /// برگردانده می‌شود و در غیر این صورت null همراه با دلیل.
        /// </summary>
        private static string ValidateReadOnly(string raw, out string problem)
        {
            problem = null;
            if (string.IsNullOrWhiteSpace(raw)) { problem = "کوئری خالی است"; return null; }

            var body = raw.Trim().TrimEnd(';').Trim();
            if (body.IndexOf(';') >= 0) { problem = "چند دستور در یک کوئری مجاز نیست"; return null; }

            var head = body.Split(' ')[0].ToUpperInvariant();
            if (head != "SELECT" && head != "WITH")
            {
                problem = "فقط SELECT یا WITH مجاز است";
                return null;
            }

            var upper = body.ToUpperInvariant();
            foreach (var kw in Forbidden)
            {
                if (Regex.IsMatch(upper, @"(?<![A-Z0-9_#])" + kw + @"(?![A-Z0-9_])"))
                {
                    problem = "دستور «" + kw + "» در حالت فقط-خواندنی مجاز نیست";
                    return null;
                }
            }
            return body;
        }

        // ------------------------------------------------------------ اتصال

        /// <summary>
        /// رشتهٔ اتصال. ترتیب اولویت:
        ///   ۱) connectionStrings/MReportDb اگر تعریف شده باشد
        ///   ۲) ساخت از appSettings: Server (+ MReportPort)، DatabaseName،
        ///      MReportUser/MReportPassword — یا Windows Authentication اگر کاربر نبود
        /// نام دیتابیسِ ارسالی از کلاینت فقط در صورت [A-Za-z0-9_] پذیرفته می‌شود.
        /// </summary>
        private static string BuildConnectionString(string requestedDb)
        {
            var named = ConfigurationManager.ConnectionStrings["MReportDb"];
            if (named != null && !string.IsNullOrWhiteSpace(named.ConnectionString))
                return named.ConnectionString;

            var server = ConfigurationManager.AppSettings["Server"] ?? ".";
            var port = ConfigurationManager.AppSettings["MReportPort"];
            var db = ConfigurationManager.AppSettings["DatabaseName"] ?? "Atiran2";

            if (!string.IsNullOrWhiteSpace(requestedDb) && Regex.IsMatch(requestedDb, @"^[A-Za-z0-9_]{1,128}$"))
                db = requestedDb;

            var dataSource = string.IsNullOrWhiteSpace(port) ? server : server + "," + port;
            var user = ConfigurationManager.AppSettings["MReportUser"];
            var pwd = ConfigurationManager.AppSettings["MReportPassword"];

            var sb = "data source=" + dataSource + ";initial catalog=" + db + ";packet size=4096;";
            if (!string.IsNullOrWhiteSpace(user))
                sb += "user id=" + user + ";password=" + pwd + ";";
            else
                sb += "Integrated Security=SSPI;";
            return sb;
        }

        // ------------------------------------------------------------ ابزارها

        /// <summary>اگر appSettings/MReportKey تنظیم شده باشد، هدر باید همان باشد</summary>
        private IHttpActionResult CheckKey()
        {
            var expected = ConfigurationManager.AppSettings["MReportKey"];
            if (string.IsNullOrWhiteSpace(expected)) return null;

            var got = System.Web.HttpContext.Current != null
                ? System.Web.HttpContext.Current.Request.Headers["X-MReport-Key"]
                : null;
            return string.Equals(got, expected, StringComparison.Ordinal)
                ? null
                : (IHttpActionResult)Unauthorized();
        }

        private static object Fail(string message)
        {
            return new { ok = false, columns = new string[0], rows = new List<List<string>>(), truncated = false, rowCount = 0, elapsedMs = 0, error = message };
        }

        /// <summary>
        /// تبدیل جای‌نمای JDBC (`?`) به `@p0`, `@p1`, … — دقیقاً همان کاری که
        /// سمت اپ انجام می‌دهد. `?`های داخل رشتهٔ لیترال دست‌نخورده می‌مانند و
        /// `''` به‌عنوان escape درست شناخته می‌شود.
        /// </summary>
        /// <summary>
        /// نوع SqlParameter از نوع واقعی مقدار گرفته می‌شود.
        /// SQL Server در OFFSET/FETCH فقط عدد صحیح می‌پذیرد؛ بستن همان مقدار به‌صورت
        /// NVarChar خطای «The number of rows provided for a OFFSET clause must be an
        /// integer» می‌دهد و صفحه‌بندی همهٔ جدول‌ها از کار می‌افتد.
        /// </summary>
        private static void AddParam(SqlCommand cmd, string name, object v)
        {
            if (v == null)
            {
                var pn = cmd.Parameters.Add(name, SqlDbType.NVarChar, 4000);
                pn.Value = DBNull.Value;
                return;
            }
            if (v is bool)
            {
                cmd.Parameters.Add(name, SqlDbType.Bit).Value = v;
                return;
            }
            if (v is int || v is long || v is short || v is byte || v is uint || v is ulong)
            {
                cmd.Parameters.Add(name, SqlDbType.BigInt)
                   .Value = Convert.ToInt64(v, CultureInfo.InvariantCulture);
                return;
            }
            if (v is decimal || v is double || v is float)
            {
                cmd.Parameters.Add(name, SqlDbType.Decimal)
                   .Value = Convert.ToDecimal(v, CultureInfo.InvariantCulture);
                return;
            }
            var p = cmd.Parameters.Add(name, SqlDbType.NVarChar, 4000);
            p.Value = Convert.ToString(v, CultureInfo.InvariantCulture) ?? (object)DBNull.Value;
        }

        private static string BindPlaceholders(string sql)
        {
            if (string.IsNullOrEmpty(sql) || sql.IndexOf('?') < 0) return sql;
            var sb = new System.Text.StringBuilder(sql.Length + 16);
            var inStr = false;
            var n = 0;
            for (var i = 0; i < sql.Length; i++)
            {
                var c = sql[i];
                if (c == '\'')
                {
                    if (inStr && i + 1 < sql.Length && sql[i + 1] == '\'') { sb.Append("''"); i++; continue; }
                    inStr = !inStr;
                    sb.Append(c);
                }
                else if (c == '?' && !inStr) { sb.Append("@p").Append(n); n++; }
                else sb.Append(c);
            }
            return sb.ToString();
        }

        private static int Clamp(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

        private static string Safe(IDataRecord r, int i) { return r.IsDBNull(i) ? "" : r.GetValue(i).ToString(); }

        private static string FirstLine(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            var idx = s.IndexOf('\n');
            return (idx < 0 ? s : s.Substring(0, idx)).Trim();
        }

        /// <summary>
        /// همهٔ مقدارها به متن تبدیل می‌شوند تا قرارداد JSON ساده و پایدار بماند
        /// (null حفظ می‌شود؛ سمت اپ هم دقیقاً همین را انتظار دارد).
        /// </summary>
        private static string Format(object v)
        {
            if (v == null || v == DBNull.Value) return null;
            if (v is DateTime) return ((DateTime)v).ToString("yyyy-MM-dd HH:mm:ss");
            if (v is byte[]) return Convert.ToBase64String((byte[])v);
            if (v is bool) return ((bool)v) ? "1" : "0";
            return Convert.ToString(v, System.Globalization.CultureInfo.InvariantCulture);
        }
    }
}
