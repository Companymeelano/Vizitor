
## SQL Server / Atiran diagnostics

SQL Server tooling is included under `server/tools/`. The IIS installer provisions/detects Microsoft ODBC Driver 17/18 and PHP `sqlsrv`/`pdo_sqlsrv`; the diagnostic scripts verify the environment without restarting or reconfiguring the accounting SQL Server.
