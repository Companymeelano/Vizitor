# Vizitor 2.14.2 — Atiran SQL Integration Foundation

- Added read-only SQL Server environment diagnostics.
- Added safe SQL connection test.
- Retained ODBC 17/18 and PHP sqlsrv/pdo_sqlsrv installation support.
- Kept production diagnostics non-destructive: no automatic SQL Server restart or TCP/IP modification.
- Confirmed the original 2.13.4 package contained the SQL Server service/setup/recovery tooling; 2.14.x retained the driver installation path but not those diagnostic tools.

## Authentication note

The current 2.14.x server still authenticates against `vizitor_users`, not the native Atiran user/password table. Native Atiran authentication must be mapped only after the real Atiran user schema and password verification mechanism are inspected.
