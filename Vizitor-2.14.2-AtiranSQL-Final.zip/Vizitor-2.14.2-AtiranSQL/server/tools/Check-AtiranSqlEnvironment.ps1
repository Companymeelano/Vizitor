[CmdletBinding()]
param([string]$SqlHost='127.0.0.1',[int]$SqlPort=1433,[switch]$NoNetworkTest)
$ErrorActionPreference='Stop'; function OK($m){Write-Host "[OK] $m" -ForegroundColor Green}; function WARN($m){Write-Host "[WARN] $m" -ForegroundColor Yellow}; function FAIL($m){Write-Host "[FAIL] $m" -ForegroundColor Red}
Write-Host 'Vizitor / Atiran SQL Environment Check' -ForegroundColor Cyan
Write-Host 'READ-ONLY: no SQL restart, TCP/IP change, firewall change, registry write, or database write.'
$services=Get-Service -ErrorAction SilentlyContinue|Where-Object{$_.Name -eq 'MSSQLSERVER' -or $_.Name -like 'MSSQL$*' -or $_.DisplayName -like 'SQL Server (*'}
if($services){foreach($s in $services){if($s.Status -eq 'Running'){OK "SQL service $($s.Name): Running"}else{WARN "SQL service $($s.Name): $($s.Status)"}}}else{WARN 'No local SQL Server service detected; Atiran may be on another host.'}
$odbc18=Test-Path 'HKLM:\SOFTWARE\ODBC\ODBCINST.INI\ODBC Driver 18 for SQL Server';$odbc17=Test-Path 'HKLM:\SOFTWARE\ODBC\ODBCINST.INI\ODBC Driver 17 for SQL Server';if($odbc18){OK 'ODBC Driver 18 installed'}elseif($odbc17){OK 'ODBC Driver 17 installed'}else{FAIL 'ODBC Driver 17/18 not detected'}
$php=Get-Command php.exe -ErrorAction SilentlyContinue;if($php){$mods=@(& $php.Source -m 2>$null|ForEach-Object{"$($_)".Trim()});if($mods -contains 'pdo_sqlsrv'){OK "pdo_sqlsrv loaded (PHP $(& $php.Source -r 'echo PHP_VERSION;'))"}else{FAIL 'pdo_sqlsrv not loaded'};if($mods -contains 'sqlsrv'){OK 'sqlsrv loaded'}else{WARN 'sqlsrv not loaded'}}else{WARN 'php.exe not found in PATH'}
if(-not $NoNetworkTest){try{$r=Test-NetConnection $SqlHost -Port $SqlPort -WarningAction SilentlyContinue;if($r.TcpTestSucceeded){OK "TCP $SqlHost`:$SqlPort reachable"}else{FAIL "TCP $SqlHost`:$SqlPort unreachable"}}catch{FAIL "TCP test failed: $($_.Exception.Message)"}}
$instReg='HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL';if(Test-Path $instReg){$p=Get-ItemProperty $instReg;$n=$p.PSObject.Properties|Where-Object{$_.Name -notmatch '^PS'}|ForEach-Object{"$($_.Name)=$($_.Value)"};if($n){OK ('SQL instances: '+($n -join ', '))}}else{WARN 'Local SQL instance registry key not found'}
Write-Host 'Check complete.' -ForegroundColor Cyan
