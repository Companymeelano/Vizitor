# ابزارهای SQL Server آتیران برای Vizitor

- `Check-AtiranSqlEnvironment.ps1`: بررسی read-only سرویس‌های SQL Server، ODBC 17/18، PHP/pdo_sqlsrv، پورت 1433 و Instanceهای محلی. هیچ Restart یا تغییر تنظیماتی انجام نمی‌دهد.
- `Test-AtiranSqlConnection.ps1`: فقط یک اتصال و SELECT آزمایشی؛ هیچ INSERT/UPDATE/DELETE ندارد.

نسخه 2.13.4 ابزارهای Setup/Recovery گسترده‌تری داشت، اما برای Production بهتر است تشخیص SQL از تغییر خودکار سرویس حسابداری جدا باشد تا در ساعات کاری قطع اتصال رخ ندهد.

معماری: `Android → HTTPS/IIS → PHP FastCGI → PDO_SQLSRV → SQL Server Atiran`

پورت 1433 نباید برای Android روی اینترنت باز شود؛ فقط وب‌سرور Vizitor باید به SQL Server دسترسی داشته باشد.
